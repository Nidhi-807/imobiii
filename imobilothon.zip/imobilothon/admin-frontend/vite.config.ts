import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// GuardrailIQ Admin Console -- deliberately served on its own port, separate
// from the end-user app, so admin sign-in/registration and Conflict Desk
// decisions live at their own address rather than inside the main app.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,
  },
})
