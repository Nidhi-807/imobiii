import { useEffect, useState } from "react";

type Theme = "light" | "dark" | "system";
const STORAGE_KEY = "guardrailiq_theme";

function apply(theme: Theme) {
  const root = document.documentElement;
  if (theme === "system") root.removeAttribute("data-theme");
  else root.setAttribute("data-theme", theme);
}

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      return (localStorage.getItem(STORAGE_KEY) as Theme) || "system";
    } catch {
      return "system";
    }
  });

  useEffect(() => {
    apply(theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      // ignore storage failures -- theme just won't persist
    }
  }, [theme]);

  function toggle() {
    const prefersDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches;
    setThemeState((current) => {
      const currentlyDark = current === "dark" || (current === "system" && prefersDark);
      return currentlyDark ? "light" : "dark";
    });
  }

  return { theme, setTheme: setThemeState, toggle };
}
