import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import "./AdminFileUploadButton.scss";

interface Props {
  label?: string;
  extract: (file: File) => Promise<{ text: string; suggested_title?: string }>;
  onExtracted: (text: string, suggestedTitle?: string) => void;
}

export function AdminFileUploadButton({ label = "Upload file (.txt, .md, .pdf)", extract, onExtracted }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const result = await extract(file);
      onExtracted(result.text, result.suggested_title);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-upload-button">
      <input
        ref={inputRef}
        type="file"
        accept=".txt,.md,.pdf,text/plain,application/pdf"
        hidden
        onChange={handleChange}
      />
      <button type="button" className="admin-upload-trigger" onClick={() => inputRef.current?.click()} disabled={busy}>
        <Upload size={14} /> {busy ? "Extracting…" : label}
      </button>
      {error && <p className="admin-upload-error">{error}</p>}
    </div>
  );
}
