import { useState } from "react";
import { Moon, ShieldCheck, Sun } from "lucide-react";
import { useAuth } from "../auth/AuthContext";
import { useTheme } from "../theme";
import "./AdminAuth.scss";

export function AdminAuth() {
  const { login, register } = useAuth();
  const { theme, toggle } = useTheme();
  const isDark = theme === "dark" || (theme === "system" && window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "login") {
        await login(username, password);
      } else {
        await register(username, email, password, displayName || undefined);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-auth-page">
      <button className="admin-auth-theme-toggle" onClick={toggle} aria-label="Toggle dark mode" title="Toggle dark mode">
        {isDark ? <Sun size={16} /> : <Moon size={16} />}
      </button>
      <div className="admin-auth">
        <div className="admin-auth-brand">
          <ShieldCheck size={26} />
          <div>
            <h1>CompliX Admin Console</h1>
            <p>Governance reviewer sign-in</p>
          </div>
        </div>
        <div className="admin-auth-tabs">
          <button className={mode === "login" ? "active" : ""} onClick={() => setMode("login")}>
            Sign in
          </button>
          <button className={mode === "register" ? "active" : ""} onClick={() => setMode("register")}>
            Register
          </button>
        </div>
        <p className="admin-auth-note">
          This console is where a human reviewer actually decides open Conflict Desk tickets — CompliX
          recommends, a registered admin decides. Every decision is attributed to the signed-in account.
        </p>
        <form onSubmit={submit} className="admin-auth-form">
          <label>
            Username
            <input value={username} onChange={(e) => setUsername(e.target.value)} required autoComplete="username" />
          </label>
          {mode === "register" && (
            <>
              <label>
                Email
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </label>
              <label>
                Display name (optional)
                <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              </label>
            </>
          )}
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
            />
          </label>
          {error && <p className="admin-auth-error">{error}</p>}
          <button className="btn-primary admin-auth-submit" type="submit" disabled={busy}>
            {busy ? "Working…" : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>
      </div>
    </div>
  );
}
