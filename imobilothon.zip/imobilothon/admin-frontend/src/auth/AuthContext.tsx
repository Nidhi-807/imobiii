import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, getStoredToken, setStoredToken, type AdminInfo } from "../api/client";

interface AuthState {
  admin: AdminInfo | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string, displayName?: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [admin, setAdmin] = useState<AdminInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getStoredToken();
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .me()
      .then(setAdmin)
      .catch(() => setStoredToken(null))
      .finally(() => setLoading(false));
  }, []);

  async function login(username: string, password: string) {
    const res = await api.login({ username, password });
    setStoredToken(res.token);
    setAdmin(res.admin);
  }

  async function register(username: string, email: string, password: string, displayName?: string) {
    const res = await api.register({ username, email, password, display_name: displayName });
    setStoredToken(res.token);
    setAdmin(res.admin);
  }

  function logout() {
    api.logout().catch(() => {});
    setStoredToken(null);
    setAdmin(null);
  }

  return <AuthContext.Provider value={{ admin, loading, login, register, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
