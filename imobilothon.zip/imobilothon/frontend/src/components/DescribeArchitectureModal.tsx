import { useState } from "react";
import { X } from "lucide-react";
import "./DescribeArchitectureModal.scss";

interface Props {
  onClose: () => void;
  onSubmit: (description: string, title: string) => void;
}

export function DescribeArchitectureModal({ onClose, onSubmit }: Props) {
  const [title, setTitle] = useState("");
  const [components, setComponents] = useState("");
  const [dataFlow, setDataFlow] = useState("");
  const [hosting, setHosting] = useState("");
  const [controls, setControls] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const description = [
      components && `Components: ${components}`,
      dataFlow && `Data flow: ${dataFlow}`,
      hosting && `Hosting: ${hosting}`,
      controls && `Security controls: ${controls}`,
    ]
      .filter(Boolean)
      .join(". ");
    if (!description.trim()) return;
    onSubmit(description, title || "Described architecture");
  }

  return (
    <div className="describe-arch-backdrop" onClick={onClose}>
      <div className="describe-arch-modal" onClick={(e) => e.stopPropagation()}>
        <div className="describe-arch-header">
          <span>Describe your architecture</span>
          <button onClick={onClose} aria-label="Close">
            <X size={16} />
          </button>
        </div>
        <p className="describe-arch-sub">
          Answer what applies — this gets assembled into a design description and evaluated exactly like a typed
          message or uploaded diagram.
        </p>
        <form onSubmit={submit} className="describe-arch-form">
          <label>
            Title (optional)
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Customer analytics dashboard" />
          </label>
          <label>
            Components
            <textarea
              value={components}
              onChange={(e) => setComponents(e.target.value)}
              rows={2}
              placeholder="e.g. web app, API, Postgres database, S3 bucket"
            />
          </label>
          <label>
            Data flow
            <textarea
              value={dataFlow}
              onChange={(e) => setDataFlow(e.target.value)}
              rows={2}
              placeholder="e.g. user data flows from the web app to the API to the database"
            />
          </label>
          <label>
            Hosting
            <input value={hosting} onChange={(e) => setHosting(e.target.value)} placeholder="e.g. AWS, EU region" />
          </label>
          <label>
            Security controls
            <textarea
              value={controls}
              onChange={(e) => setControls(e.target.value)}
              rows={2}
              placeholder="e.g. SSO with MFA, TLS in transit, encryption at rest"
            />
          </label>
          <button className="btn-primary" type="submit">
            Evaluate this architecture
          </button>
        </form>
      </div>
    </div>
  );
}
