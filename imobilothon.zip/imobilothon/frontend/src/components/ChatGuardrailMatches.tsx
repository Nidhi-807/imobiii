import { SeverityBadge, Chip } from "../design-system/Badge";
import "./ChatFindings.scss";

interface GuardrailMatch {
  id: string;
  statement: string;
  severity: string;
  domain: string;
  similarity: number;
}

interface Props {
  matches: GuardrailMatch[];
}

/** Renders guardrail search matches with the same severity badge colors used
 * throughout the app, instead of a plain emoji-prefixed text list. */
export function ChatGuardrailMatches({ matches }: Props) {
  if (matches.length === 0) return null;

  return (
    <div className="chat-findings">
      {matches.map((g, i) => (
        <div key={i} className="chat-finding-card">
          <div className="chat-finding-header">
            <SeverityBadge severity={g.severity} />
            <Chip>{g.id}</Chip>
            <Chip>{g.domain}</Chip>
          </div>
          <p className="chat-finding-text">{g.statement}</p>
        </div>
      ))}
    </div>
  );
}
