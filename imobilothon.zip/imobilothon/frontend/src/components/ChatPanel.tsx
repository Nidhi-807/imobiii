import { useState, useRef, useEffect } from "react";
import { SendHorizontal, Plus, MessageSquare, Trash2, ShieldCheck, User as UserIcon, FileText, X } from "lucide-react";
import { api, type Citation, type TraceStep, type ResponseSection, type EvaluationReport } from "../api/client";
import { useUserAuth } from "../auth/UserAuthContext";
import { AgentTrace, agentTraceDurationMs } from "./AgentTrace";
import { AttachMenu } from "./AttachMenu";
import { ChatFindings } from "./ChatFindings";
import { ChatGuardrailMatches } from "./ChatGuardrailMatches";
import { Citations } from "./Citations";
import { DescribeArchitectureModal } from "./DescribeArchitectureModal";
import { DocumentPreview } from "./DocumentPreview";
import { FormattedMessage } from "./FormattedMessage";
import { ImageLightbox } from "./ImageLightbox";
import { ChatSettingsButton, ChatSettingsPanel, type ChatSettingsState } from "./ChatSettings";
import "./ChatPanel.scss";

interface Message {
  role: "user" | "assistant";
  text: string;
  intent?: string;
  citations?: Citation[];
  trace?: TraceStep[];
  sections?: ResponseSection[];
  imagePreviewUrl?: string;
  report?: EvaluationReport | null;
  guardrailMatches?: { id: string; statement: string; severity: string; domain: string; similarity: number }[];
}

interface StagedFile {
  file: File;
  kind: "diagram" | "text";
  previewUrl: string | null;
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastDesignId?: string;
}

// Follow-up questions about an already-shared diagram/design, asked without a
// new attachment -- e.g. "ELI5 this diagram" -- route to /chat/explain
// instead of a fresh guardrail search that would find nothing new.
const EXPLAIN_FOLLOWUP_RE = /\b(eli5|explain|simplify|walk (me )?through|summari[sz]e|describe)\b/i;

const SUGGESTIONS = [
  "Show mandatory Information Security guardrails about encryption",
  "Evaluate the public customer file share design",
  "Show me open conflicts",
];

const THINKING_PHRASES = ["Routing your request…", "Consulting the guardrail model…"];

function welcomeMessage(name: string): Message {
  return {
    role: "assistant",
    text: `Hi ${name}. Ask me to search guardrails, evaluate a design, or check open conflicts — every answer traces back to a source clause.`,
  };
}

const SESSIONS_KEY = "guardrailiq_chat_sessions";
const SETTINGS_KEY = "guardrailiq_chat_settings";
const DEFAULT_SETTINGS: ChatSettingsState = { showTrace: true, showThinkingPhrases: true };

function readLocalStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw) as T;
  } catch {
    // ignore corrupt/missing storage
  }
  return fallback;
}

function writeLocalStorage(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore storage failures
  }
}

function newSession(userName: string): ChatSession {
  return { id: crypto.randomUUID(), title: "New chat", messages: [welcomeMessage(userName)] };
}

export function ChatPanel() {
  const { user } = useUserAuth();
  const displayName = user?.display_name || user?.username || "there";

  const [settings, setSettings] = useState<ChatSettingsState>(() => readLocalStorage(SETTINGS_KEY, DEFAULT_SETTINGS));
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const stored = readLocalStorage<ChatSession[] | null>(SESSIONS_KEY, null);
    return stored && stored.length > 0 ? stored : [newSession(displayName)];
  });
  const [activeId, setActiveId] = useState(sessions[0].id);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [pendingTrace, setPendingTrace] = useState<TraceStep[] | null>(null);
  const [thinkingPhrase, setThinkingPhrase] = useState(THINKING_PHRASES[0]);
  const [previewClauseId, setPreviewClauseId] = useState<string | null>(null);
  const [llmMode, setLlmMode] = useState<Awaited<ReturnType<typeof api.llmStatus>> | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [attachMenuOpen, setAttachMenuOpen] = useState(false);
  const [describeOpen, setDescribeOpen] = useState(false);
  const [stagedFile, setStagedFile] = useState<StagedFile | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const active = sessions.find((s) => s.id === activeId) ?? sessions[0];

  useEffect(() => writeLocalStorage(SESSIONS_KEY, sessions), [sessions]);
  useEffect(() => writeLocalStorage(SETTINGS_KEY, settings), [settings]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [active?.messages, pendingTrace, loading]);

  useEffect(() => {
    api.llmStatus().then(setLlmMode).catch(() => {});
  }, []);

  useEffect(() => {
    if (!loading || pendingTrace || !settings.showThinkingPhrases) return;
    let i = 0;
    const id = setInterval(() => {
      i = (i + 1) % THINKING_PHRASES.length;
      setThinkingPhrase(THINKING_PHRASES[i]);
    }, 1100);
    return () => clearInterval(id);
  }, [loading, pendingTrace, settings.showThinkingPhrases]);

  function updateActive(fn: (s: ChatSession) => ChatSession) {
    setSessions((all) => all.map((s) => (s.id === activeId ? fn(s) : s)));
  }

  function startNewChat() {
    const session = newSession(displayName);
    setSessions((all) => [session, ...all]);
    setActiveId(session.id);
  }

  function deleteChat(id: string) {
    setSessions((all) => {
      const remaining = all.filter((s) => s.id !== id);
      if (remaining.length === 0) {
        const fresh = newSession(displayName);
        if (id === activeId) setActiveId(fresh.id);
        return [fresh];
      }
      if (id === activeId) setActiveId(remaining[0].id);
      return remaining;
    });
  }

  function commitReply(res: {
    reply: string;
    intent: string;
    sections?: ResponseSection[];
    citations: Citation[];
    trace: TraceStep[];
    design_id?: string;
    data?: unknown;
  }) {
    const report = res.intent === "evaluate" || res.intent === "diagram" ? (res.data as EvaluationReport | null) ?? undefined : undefined;
    const guardrailMatches =
      res.intent === "search" && Array.isArray(res.data)
        ? (res.data as { id: string; statement: string; severity: string; domain: string; similarity: number }[])
        : undefined;

    const commit = () => {
      updateActive((s) => ({
        ...s,
        lastDesignId: res.design_id ?? s.lastDesignId,
        messages: [
          ...s.messages,
          {
            role: "assistant",
            text: res.reply,
            intent: res.intent,
            sections: res.sections,
            citations: res.citations,
            trace: res.trace,
            report,
            guardrailMatches,
          },
        ],
      }));
      setLoading(false);
      setPendingTrace(null);
    };

    // Hold the finished answer back until the agent-trace animation plays
    // through, so the workflow steps visibly happen *before* the answer
    // appears -- not decorated onto an already-completed message.
    if (settings.showTrace && res.trace?.length) {
      setPendingTrace(res.trace);
      setTimeout(commit, agentTraceDurationMs(res.trace));
    } else {
      commit();
    }
  }

  function stageDiagramFile(file: File) {
    setStagedFile((prev) => {
      if (prev?.previewUrl) URL.revokeObjectURL(prev.previewUrl);
      return { file, kind: "diagram", previewUrl: URL.createObjectURL(file) };
    });
  }

  function stageTextFile(file: File) {
    setStagedFile((prev) => {
      if (prev?.previewUrl) URL.revokeObjectURL(prev.previewUrl);
      return { file, kind: "text", previewUrl: null };
    });
  }

  function clearStagedFile() {
    setStagedFile((prev) => {
      if (prev?.previewUrl) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
  }

  async function send(text: string) {
    if (loading) return;
    const attachment = stagedFile;
    if (!text.trim() && !attachment) return;

    // A plain follow-up question (no new attachment) about an already-shared
    // diagram/design -- e.g. "ELI5 this diagram" -- reuses that design instead
    // of running a fresh guardrail search that would find nothing new.
    const wantsExplain = !attachment && !!active.lastDesignId && EXPLAIN_FOLLOWUP_RE.test(text);

    // Attaching a file no longer sends immediately -- it's staged so the
    // user can type a question alongside it, then both go together.
    const label = attachment ? `📎 ${attachment.file.name}${text.trim() ? `\n${text.trim()}` : ""}` : text;
    const isFirstUserMessage = !active.messages.some((m) => m.role === "user");
    updateActive((s) => ({
      ...s,
      title: isFirstUserMessage ? (attachment ? attachment.file.name : text).slice(0, 42) : s.title,
      messages: [
        ...s.messages,
        {
          role: "user",
          text: label,
          imagePreviewUrl: attachment?.kind === "diagram" ? attachment.previewUrl ?? undefined : undefined,
        },
      ],
    }));
    setInput("");
    setStagedFile(null);
    setLoading(true);
    setPendingTrace(null);
    setThinkingPhrase(attachment ? "Analyzing the attachment…" : wantsExplain ? "Explaining the architecture…" : THINKING_PHRASES[0]);

    try {
      const res = attachment
        ? attachment.kind === "diagram"
          ? await api.attachDiagram(attachment.file, "Information Security", text.trim())
          : await api.attachTextFile(attachment.file, "Information Security", text.trim())
        : wantsExplain
          ? await api.explainDesign(active.lastDesignId!, text)
          : await api.chat(text);
      commitReply(res);
    } catch (e) {
      updateActive((s) => ({
        ...s,
        messages: [...s.messages, { role: "assistant", text: `Error: ${(e as Error).message}` }],
      }));
      setLoading(false);
      setPendingTrace(null);
    }
  }

  async function describeArchitecture(description: string, title: string) {
    setDescribeOpen(false);
    if (loading) return;
    updateActive((s) => ({ ...s, messages: [...s.messages, { role: "user", text: title }] }));
    setLoading(true);
    setPendingTrace(null);
    setThinkingPhrase("Evaluating the described architecture…");

    try {
      commitReply(await api.evaluateDescribedArchitecture(description, title));
    } catch (e) {
      updateActive((s) => ({
        ...s,
        messages: [...s.messages, { role: "assistant", text: `Error: ${(e as Error).message}` }],
      }));
      setLoading(false);
      setPendingTrace(null);
    }
  }

  async function openCitation(citation: Citation) {
    if (citation.clause_id) {
      setPreviewClauseId(citation.clause_id);
      return;
    }
    try {
      const g = await api.getGuardrail(citation.guardrail_id);
      if (g.sources[0]) setPreviewClauseId(g.sources[0].clause_id);
    } catch {
      // no-op -- preview just won't open
    }
  }

  return (
    <div className="chat-layout">
      <aside className="chat-history">
        <button className="chat-new-btn" onClick={startNewChat}>
          <Plus size={15} /> New chat
        </button>
        <div className="chat-history-heading">Chat history</div>
        <div className="chat-history-list">
          {sessions.map((s) => (
            <div key={s.id} className={`chat-history-item ${s.id === activeId ? "active" : ""}`}>
              <button className="chat-history-item-main" onClick={() => setActiveId(s.id)}>
                <MessageSquare size={14} />
                <span>{s.title}</span>
              </button>
              <button
                className="chat-history-item-delete"
                onClick={() => deleteChat(s.id)}
                aria-label={`Delete "${s.title}"`}
                title="Delete chat"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </div>
      </aside>

      <div className="chat-panel">
        <div className="chat-panel-header">
          <span className="chat-panel-header-title">CompliX Assistant</span>
          <div className="chat-panel-header-right">
            <ChatSettingsButton open={settingsOpen} onToggleOpen={() => setSettingsOpen((o) => !o)} />
          </div>
          <ChatSettingsPanel
            open={settingsOpen}
            onToggleOpen={() => setSettingsOpen(false)}
            settings={settings}
            onSettingsChange={setSettings}
            llmMode={llmMode}
          />
        </div>

        <div className="chat-messages">
          {active.messages.map((m, i) => (
            <div key={i} className={`chat-row chat-row-${m.role}`}>
              <span className={`chat-avatar chat-avatar-${m.role}`}>
                {m.role === "assistant" ? <ShieldCheck size={15} /> : <UserIcon size={15} />}
              </span>
              <div className={`chat-bubble chat-bubble-${m.role}`}>
                {m.role === "assistant" && settings.showTrace && m.trace && <AgentTrace steps={m.trace} />}
                {m.imagePreviewUrl && (
                  <img
                    className="chat-bubble-thumb"
                    src={m.imagePreviewUrl}
                    alt="Attached diagram thumbnail"
                    onClick={() => setLightboxUrl(m.imagePreviewUrl!)}
                  />
                )}
                <div className="chat-bubble-text">
                  {m.role === "assistant" ? <FormattedMessage text={m.text} sections={m.sections} /> : m.text}
                </div>
                {m.role === "assistant" && m.report?.findings && (
                  <ChatFindings findings={[...m.report.findings, ...(m.report.unverified_suppressed ?? [])]} />
                )}
                {m.role === "assistant" && m.guardrailMatches && <ChatGuardrailMatches matches={m.guardrailMatches} />}
                {m.citations && <Citations citations={m.citations} onOpen={openCitation} />}
              </div>
            </div>
          ))}
          {loading && (
            <div className="chat-row chat-row-assistant">
              <span className="chat-avatar chat-avatar-assistant">
                <ShieldCheck size={15} />
              </span>
              <div className="chat-bubble chat-bubble-assistant chat-loading">
                {settings.showTrace && pendingTrace ? (
                  <AgentTrace steps={pendingTrace} />
                ) : (
                  <span className="chat-loading-text">
                    <span className="chat-loading-dot" />
                    {settings.showThinkingPhrases ? thinkingPhrase : "Working…"}
                  </span>
                )}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <div className="chat-suggestions">
          {SUGGESTIONS.map((s) => (
            <button key={s} className="chat-suggestion-chip" onClick={() => send(s)}>
              {s}
            </button>
          ))}
        </div>
        {stagedFile && (
          <div className="chat-staged-attachment">
            {stagedFile.kind === "diagram" && stagedFile.previewUrl ? (
              <img
                className="chat-staged-thumb"
                src={stagedFile.previewUrl}
                alt="Attachment preview"
                onClick={() => setLightboxUrl(stagedFile.previewUrl)}
              />
            ) : (
              <span className="chat-staged-file-chip">
                <FileText size={14} />
              </span>
            )}
            <span className="chat-staged-name">{stagedFile.file.name}</span>
            <button type="button" className="chat-staged-remove" onClick={clearStagedFile} aria-label="Remove attachment">
              <X size={14} />
            </button>
          </div>
        )}
        <form
          className="chat-input-row"
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <AttachMenu
            open={attachMenuOpen}
            onToggleOpen={() => setAttachMenuOpen((o) => !o)}
            onPickDiagram={stageDiagramFile}
            onPickTextFile={stageTextFile}
            onDescribeArchitecture={() => setDescribeOpen(true)}
            disabled={loading}
          />
          <input
            className="chat-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={stagedFile ? "Add a question about this attachment (optional)…" : "Ask CompliX…"}
          />
          <button className="chat-send" type="submit" disabled={loading || (!input.trim() && !stagedFile)} aria-label="Send">
            <SendHorizontal size={16} />
          </button>
        </form>
      </div>

      {describeOpen && (
        <DescribeArchitectureModal onClose={() => setDescribeOpen(false)} onSubmit={describeArchitecture} />
      )}

      <DocumentPreview clauseId={previewClauseId} onClose={() => setPreviewClauseId(null)} />
      <ImageLightbox url={lightboxUrl} onClose={() => setLightboxUrl(null)} />
    </div>
  );
}
