import { X } from "lucide-react";
import "./ImageLightbox.scss";

interface Props {
  url: string | null;
  onClose: () => void;
}

/** Full-size preview for an attached/sent diagram thumbnail. */
export function ImageLightbox({ url, onClose }: Props) {
  if (!url) return null;
  return (
    <div className="image-lightbox-backdrop" onClick={onClose}>
      <button className="image-lightbox-close" onClick={onClose} aria-label="Close preview">
        <X size={20} />
      </button>
      <img className="image-lightbox-img" src={url} alt="Attached diagram, full size" onClick={(e) => e.stopPropagation()} />
    </div>
  );
}
