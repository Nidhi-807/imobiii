import { useEffect, useMemo, useState } from "react";
import { api, type Guardrail } from "../api/client";
import { SeverityBadge } from "../design-system/Badge";
import "./GuardrailExplorer.scss";

const SEVERITY_RANK: Record<string, number> = { Mandatory: 3, High: 2, Medium: 1, Low: 0 };

export function GuardrailExplorer() {
  const [guardrails, setGuardrails] = useState<Guardrail[]>([]);
  const [domains, setDomains] = useState<string[]>([]);
  const [domain, setDomain] = useState("");
  const [severity, setSeverity] = useState("");
  const [q, setQ] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listDomains().then(setDomains).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    api
      .listGuardrails({ domain: domain || undefined, severity: severity || undefined, q: q || undefined })
      .then(setGuardrails)
      .finally(() => setLoading(false));
  }, [domain, severity, q]);

  const stats = useMemo(
    () => ({
      total: guardrails.length,
      mandatory: guardrails.filter((g) => g.severity === "Mandatory").length,
      merged: guardrails.filter((g) => g.is_duplicate_merge).length,
      broken: guardrails.filter((g) => g.broken_reference).length,
    }),
    [guardrails],
  );

  const grouped = useMemo(() => {
    const byDomain = new Map<string, Guardrail[]>();
    for (const g of guardrails) {
      if (!byDomain.has(g.domain)) byDomain.set(g.domain, []);
      byDomain.get(g.domain)!.push(g);
    }
    for (const list of byDomain.values()) {
      list.sort((a, b) => (SEVERITY_RANK[b.severity] ?? 0) - (SEVERITY_RANK[a.severity] ?? 0));
    }
    return [...byDomain.entries()].sort((a, b) => b[1].length - a[1].length);
  }, [guardrails]);

  return (
    <div className="guardrail-explorer">
      <h1>Guardrail Explorer</h1>
      <p className="explorer-sub">
        Every guardrail below was derived from real clauses, not typed in by hand — expand a row to see its sources,
        and any duplicate-merge or broken-reference flags.
      </p>

      <div className="explorer-stats">
        <div className="explorer-stat">
          <span className="explorer-stat-value">{stats.total}</span>
          <span className="explorer-stat-label">Guardrails</span>
        </div>
        <div className="explorer-stat">
          <span className="explorer-stat-value">{stats.mandatory}</span>
          <span className="explorer-stat-label">Mandatory</span>
        </div>
        <div className="explorer-stat">
          <span className="explorer-stat-value">{grouped.length}</span>
          <span className="explorer-stat-label">Domains shown</span>
        </div>
        <div className={`explorer-stat ${stats.merged > 0 ? "explorer-stat-amber" : ""}`}>
          <span className="explorer-stat-value">{stats.merged}</span>
          <span className="explorer-stat-label">Duplicate merges</span>
        </div>
        <div className={`explorer-stat ${stats.broken > 0 ? "explorer-stat-alert" : ""}`}>
          <span className="explorer-stat-value">{stats.broken}</span>
          <span className="explorer-stat-label">Broken references</span>
        </div>
      </div>

      <div className="explorer-filters">
        <input
          className="explorer-search"
          placeholder="Search guardrail text…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select value={domain} onChange={(e) => setDomain(e.target.value)}>
          <option value="">All domains</option>
          {domains.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
        <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
          <option value="">All severities</option>
          {["Mandatory", "High", "Medium", "Low"].map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <p>Loading…</p>
      ) : (
        <div className="explorer-groups">
          {grouped.map(([domainName, items]) => (
            <section key={domainName} className="explorer-group">
              <div className="explorer-group-header">
                <span className="explorer-group-name">{domainName}</span>
                <span className="explorer-group-count">{items.length}</span>
              </div>
              <div className="explorer-table">
                {items.map((g) => (
                  <div key={g.id} className="explorer-row">
                    <div className="explorer-row-summary" onClick={() => setExpanded(expanded === g.id ? null : g.id)}>
                      <div className="explorer-row-top">
                        <SeverityBadge severity={g.severity} />
                        <span className="explorer-row-id">{g.id}</span>
                        <div className="explorer-row-flags">
                          {g.is_duplicate_merge && <span className="flag flag-amber">merged duplicate</span>}
                          {g.broken_reference && <span className="flag flag-red">broken reference</span>}
                        </div>
                        <span className="explorer-chevron">{expanded === g.id ? "▲" : "▼"}</span>
                      </div>
                      <p className="explorer-row-statement">{g.statement}</p>
                    </div>
                    {expanded === g.id && (
                      <div className="explorer-row-detail">
                        {g.category && (
                          <p>
                            <strong>Category:</strong> {g.category}
                          </p>
                        )}
                        {g.applicability && (
                          <p>
                            <strong>Applicability:</strong> {g.applicability}
                          </p>
                        )}
                        <p>
                          <strong>Sources</strong> ({g.sources.length}
                          {g.is_duplicate_merge ? " — preserved from all merged clauses" : ""}):
                        </p>
                        <ul>
                          {g.sources.map((s, i) => (
                            <li key={i}>
                              Clause {s.clause_id} {s.document_id && <>(Document {s.document_id})</>}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          ))}
          {guardrails.length === 0 && <p className="explorer-empty">No guardrails match these filters.</p>}
        </div>
      )}
    </div>
  );
}
