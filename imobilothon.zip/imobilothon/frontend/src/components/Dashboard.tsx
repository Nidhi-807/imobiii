import { useEffect, useState } from "react";
import { AlertTriangle, Copy, FileStack, Scale, ShieldAlert } from "lucide-react";
import { api } from "../api/client";
import "./Dashboard.scss";

const SEVERITY_ORDER = ["Mandatory", "High", "Medium", "Low"];
const SEVERITY_COLOR: Record<string, string> = {
  Mandatory: "var(--color-danger-dark)",
  High: "#f87171",
  Medium: "var(--color-warning-border)",
  Low: "var(--color-gray-300)",
};

type Summary = Awaited<ReturnType<typeof api.dashboardSummary>>;

export function Dashboard({ onNavigate }: { onNavigate: (view: "guardrails" | "conflicts") => void }) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    api.dashboardSummary().then(setSummary).finally(() => setLoading(false));
  }

  useEffect(load, []);

  if (loading || !summary) {
    return (
      <div className="dashboard">
        <h1>Dashboard</h1>
        <p>Loading…</p>
      </div>
    );
  }

  const domainEntries = Object.entries(summary.guardrails_by_domain).sort((a, b) => b[1] - a[1]);
  const maxDomainCount = Math.max(...domainEntries.map(([, v]) => v), 1);
  const severityEntries = SEVERITY_ORDER.filter((s) => summary.guardrails_by_severity[s]).map(
    (s) => [s, summary.guardrails_by_severity[s]] as const,
  );

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <p className="dashboard-sub">
        A live view of the guardrail model — every number here is computed fresh from the database, not cached, so it
        reflects the current state after any re-ingest or Conflict Desk decision.
      </p>

      <div className="stat-grid">
        <div className="stat-tile">
          <FileStack size={20} />
          <div className="stat-value">{summary.guardrails_total}</div>
          <div className="stat-label">Guardrails</div>
        </div>
        <div className="stat-tile stat-tile-clickable" onClick={() => onNavigate("guardrails")}>
          <Copy size={20} />
          <div className="stat-value">{summary.duplicates_merged}</div>
          <div className="stat-label">Duplicates merged</div>
        </div>
        <div
          className={`stat-tile stat-tile-clickable ${summary.conflicts_open > 0 ? "stat-tile-alert" : ""}`}
          onClick={() => onNavigate("conflicts")}
        >
          <Scale size={20} />
          <div className="stat-value">{summary.conflicts_open}</div>
          <div className="stat-label">Open conflicts</div>
        </div>
        <div className="stat-tile">
          <ShieldAlert size={20} />
          <div className="stat-value">{summary.conflicts_decided}</div>
          <div className="stat-label">Conflicts decided</div>
        </div>
        <div className={`stat-tile ${summary.broken_references > 0 ? "stat-tile-alert" : ""}`}>
          <AlertTriangle size={20} />
          <div className="stat-value">{summary.broken_references}</div>
          <div className="stat-label">Broken references</div>
        </div>
        <div className="stat-tile">
          <div className="stat-value">{summary.documents}</div>
          <div className="stat-label">Source documents</div>
        </div>
        <div className="stat-tile">
          <div className="stat-value">{summary.clauses}</div>
          <div className="stat-label">Clauses ingested</div>
        </div>
        <div className="stat-tile">
          <div className="stat-value">{summary.designs}</div>
          <div className="stat-label">Designs available</div>
        </div>
      </div>

      <div className="chart-grid">
        <div className="chart-card">
          <h2>Guardrails by domain</h2>
          <div className="bar-chart">
            {domainEntries.map(([domain, count]) => (
              <button key={domain} className="bar-row" onClick={() => onNavigate("guardrails")}>
                <span className="bar-label">{domain}</span>
                <span className="bar-track">
                  <span className="bar-fill" style={{ width: `${(count / maxDomainCount) * 100}%` }} />
                </span>
                <span className="bar-count">{count}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="chart-card">
          <h2>Guardrails by severity</h2>
          <div className="severity-bar">
            {severityEntries.map(([sev, count]) => (
              <div
                key={sev}
                className="severity-segment"
                style={{
                  width: `${(count / summary.guardrails_total) * 100}%`,
                  background: SEVERITY_COLOR[sev],
                }}
                title={`${sev}: ${count}`}
              />
            ))}
          </div>
          <ul className="severity-legend">
            {severityEntries.map(([sev, count]) => (
              <li key={sev}>
                <span className="legend-dot" style={{ background: SEVERITY_COLOR[sev] }} />
                {sev} — {count}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
