import { useEffect, useState } from "react";
import { ExternalLink } from "lucide-react";
import { api, type ConflictTicket } from "../api/client";
import "./ConflictDesk.scss";

const ADMIN_CONSOLE_URL = import.meta.env.VITE_ADMIN_CONSOLE_URL || "http://localhost:5174";

export function ConflictDesk() {
  const [tickets, setTickets] = useState<ConflictTicket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .listConflicts()
      .then(setTickets)
      .finally(() => setLoading(false));
  }, []);

  const open = tickets.filter((t) => t.status === "open");
  const decided = tickets.filter((t) => t.status !== "open");

  return (
    <div className="conflict-desk">
      <h1>Conflict Desk</h1>
      <p className="desk-sub">
        CompliX <strong>never</strong> silently picks a side when two sources disagree. Each ticket below shows
        both sources, why the Conflict Agent thinks they disagree, and which designs would flip verdict under each
        resolution.
      </p>

      <div className="desk-admin-banner">
        <span>
          Approving, rejecting, or keeping a ticket open requires a signed-in admin reviewer — that happens in the
          dedicated Admin Console, not here.
        </span>
        <a className="btn-primary desk-admin-link" href={ADMIN_CONSOLE_URL} target="_blank" rel="noreferrer">
          Open Admin Console <ExternalLink size={14} />
        </a>
      </div>

      {loading && <p>Loading…</p>}

      {!loading && open.length === 0 && <p className="desk-empty">No open conflicts right now.</p>}

      {open.map((t) => (
        <div key={t.id} className="conflict-ticket">
          <div className="ticket-header">
            <span className="ticket-id">{t.id}</span>
            <span className="ticket-metric">{t.metric}</span>
            <span className="ticket-status ticket-status-open">Awaiting human decision</span>
          </div>

          <div className="ticket-sides">
            <div className="ticket-side">
              <div className="ticket-side-label">Side A</div>
              <div className="ticket-side-id">{t.guardrail_a?.id}</div>
              <div className="ticket-side-statement">{t.guardrail_a?.statement}</div>
            </div>
            <div className="ticket-vs">vs</div>
            <div className="ticket-side">
              <div className="ticket-side-label">Side B</div>
              <div className="ticket-side-id">{t.guardrail_b?.id}</div>
              <div className="ticket-side-statement">{t.guardrail_b?.statement}</div>
            </div>
          </div>

          <p className="ticket-rationale">
            <strong>Why the Conflict Agent flagged this:</strong> {t.rationale}
          </p>
          <p className="ticket-recommendation">
            <strong>Recommendation:</strong> {t.recommended_resolution}
          </p>

          {t.impact_analysis && (
            <div className="ticket-impact">
              <strong>Impact analysis</strong> <span className="impact-note">({t.impact_analysis.note})</span>
              {t.impact_analysis.designs_that_flip.length === 0 ? (
                <p className="impact-empty">No existing designs would flip verdict under either resolution.</p>
              ) : (
                <ul>
                  {t.impact_analysis.designs_that_flip.map((d) => (
                    <li key={d.design_id}>
                      <strong>{d.design_id}</strong> ({d.design_title}): observed value {d.observed_value} —{" "}
                      {d.verdict_under_a} under A, {d.verdict_under_b} under B
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      ))}

      {decided.length > 0 && (
        <>
          <h2 className="desk-decided-heading">Decided</h2>
          {decided.map((t) => (
            <div key={t.id} className="conflict-ticket conflict-ticket-decided">
              <div className="ticket-header">
                <span className="ticket-id">{t.id}</span>
                <span className="ticket-metric">{t.metric}</span>
                <span className="ticket-status">{t.status.replace("_", " ")}</span>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
