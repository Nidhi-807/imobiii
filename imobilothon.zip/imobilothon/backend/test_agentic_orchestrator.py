#!/usr/bin/env python
"""
Test the agentic orchestrator with LLMaaS integration.
Demonstrates intelligent LLM reasoning throughout the chat pipeline.
"""

import requests
import json
from typing import Any

BASE_URL = "http://127.0.0.1:8000"

def pretty_print_response(resp: dict) -> None:
    """Print response in readable format."""
    print(f"\n{'='*70}")
    print(f"Intent: {resp.get('intent', 'unknown').upper()}")
    print(f"{'='*70}")
    
    print(f"\n📝 Reply:")
    print(f"  {resp.get('reply', 'N/A')}")
    
    print(f"\n🔗 Citations: {len(resp.get('citations', []))} references")
    for cite in resp.get('citations', [])[:3]:
        print(f"  - {cite.get('guardrail_id', 'N/A')} ({cite.get('label', 'N/A')})")
    
    print(f"\n📊 Agent Trace (pipeline stages):")
    for i, stage in enumerate(resp.get('trace', []), 1):
        agent = stage.get('agent', 'Unknown')
        action = stage.get('action', 'No action')
        print(f"  {i}. {agent}: {action}")
    
    if resp.get('data'):
        print(f"\n📋 Data: {len(resp['data'])} items")

def test_chat(message: str) -> None:
    """Test a chat message through the orchestrator."""
    print(f"\n\n{'*'*70}")
    print(f"Testing: {message}")
    print(f"{'*'*70}")
    
    try:
        response = requests.post(
            f"{BASE_URL}/chat",
            json={"message": message},
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            pretty_print_response(data)
        else:
            print(f"✗ Status {response.status_code}: {response.text[:200]}")
    except requests.exceptions.Timeout:
        print("⚠ Request timed out (LLMaaS may be slow)")
    except Exception as e:
        print(f"✗ Error: {type(e).__name__}: {e}")

def main():
    print("="*70)
    print("AGENTIC ORCHESTRATOR WITH LLMaaS - INTEGRATION TEST")
    print("="*70)
    
    print("\nVerifying backend connectivity...")
    try:
        resp = requests.get(f"{BASE_URL}/health", timeout=5)
        if resp.status_code == 200:
            print("✓ Backend is running and healthy")
        else:
            print("✗ Backend responded with error")
            return
    except Exception as e:
        print(f"✗ Backend not accessible: {e}")
        return
    
    # Test different query types
    test_cases = [
        ("encryption requirements", "Guardrail search - LLM analyzes intent"),
        ("check conflicts", "Conflict query - LLM analyzes competing requirements"),
        ("evaluate my API design", "Design evaluation - LLM-backed verdicts"),
        ("hi", "Small talk - regex detection (fast path)"),
    ]
    
    print("\n" + "="*70)
    print("TESTING DIFFERENT QUERY TYPES")
    print("="*70)
    
    for message, description in test_cases:
        print(f"\n▶ Testing: {description}")
        test_chat(message)
    
    print("\n" + "="*70)
    print("SUMMARY: All Agent Paths Using LLMaaS")
    print("="*70)
    print("""
✓ Small talk → Regex detection (fast)
✓ Guardrail search → LLM analyzes intent + composes intelligent response
✓ Conflict analysis → LLM provides strategic insights
✓ Design evaluation → LLM-backed verdicts with deterministic fallback

Trace shows all agent stages and LLM reasoning explicitly in response.
Citations grounded in database, never parsed from LLM prose.
""")

if __name__ == "__main__":
    main()
