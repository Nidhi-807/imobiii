#!/usr/bin/env python
"""Verify LLMaaS integration configuration and status."""

import os
from app.config import (
    LLMAAS_CLIENT_ID,
    LLMAAS_CLIENT_SECRET,
    LLMAAS_API_CLIENT_KEY,
    LLMAAS_TOKEN_URL,
    LLMAAS_BASE_URL,
    LLM_BASE_URL,
    LLM_MODEL
)
from app.llm.client import is_configured, _llmaas_configured

print("=" * 70)
print("LLMaaS CONFIGURATION VERIFICATION")
print("=" * 70)

print("\n[CONFIG VARIABLES]")
print(f"  LLMAAS_CLIENT_ID: {'✓ SET' if LLMAAS_CLIENT_ID else '✗ NOT SET'}")
print(f"  LLMAAS_CLIENT_SECRET: {'✓ SET' if LLMAAS_CLIENT_SECRET else '✗ NOT SET'}")
print(f"  LLMAAS_API_CLIENT_KEY: {'✓ SET' if LLMAAS_API_CLIENT_KEY else '✗ NOT SET'}")
print(f"  LLMAAS_TOKEN_URL: {LLMAAS_TOKEN_URL}")
print(f"  LLMAAS_BASE_URL: {LLMAAS_BASE_URL}")
print(f"  LLM_BASE_URL: {LLM_BASE_URL if LLM_BASE_URL else '(empty, will use LLMaaS)'}")
print(f"  LLM_MODEL: {LLM_MODEL}")

print("\n[ROUTING LOGIC]")
print(f"  _llmaas_configured(): {_llmaas_configured()}")
print(f"  is_configured(): {is_configured()}")

if _llmaas_configured():
    print("\n  ✓ LLMaaS is CONFIGURED")
    print("    → Endpoint will route to VW Group IDP for OAuth2 token")
    print("    → Token requests: https://idp.cloud.vwgroup.com/auth/realms/kums-mfa/protocol/openid-connect/token")
    print("    → LLM calls: https://llmapi.ai.vwgroup.com")
    print("    → Fallback: Deterministic template if token request fails")
else:
    print("\n  ✗ LLMaaS is NOT configured")
    if LLM_BASE_URL:
        print(f"    → Will use generic OpenAI-compatible endpoint: {LLM_BASE_URL}")
    else:
        print("    → Will use deterministic fallback (no LLM calls)")

print("\n[ENDPOINT STATUS]")
print("  POST /architecture/generate: ✓ Available")
print("  POST /architecture/evaluate: ✓ Available")
print("  Security: Client secret NOT logged, token cached in-process only")

print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)

if _llmaas_configured():
    print("""
✓ LLMaaS Integration is ACTIVE

The backend will now:
1. Use LLMaaS OAuth2 to authenticate
2. Call LLM for architecture generation (smarter, context-aware)
3. Fall back to deterministic template if LLM fails

Endpoints:
- POST /architecture/generate → LLMaaS-enhanced architecture
- POST /architecture/evaluate → Vision + LLMaaS compliance check
    """)
else:
    print("""
⚠ LLMaaS Not Configured

The backend is using deterministic fallback:
- POST /architecture/generate → Default secure template with citation grounding
- POST /architecture/evaluate → Regex-based exposure signal detection

To enable LLMaaS, populate backend/.env with credentials and restart backend.
    """)

print("=" * 70)
