import requests
resp = requests.post('http://127.0.0.1:8000/architecture/generate', json={'brief': 'Payment system', 'fmt': 'mermaid'})
print(f'Status: {resp.status_code}')
if resp.status_code == 200:
    data = resp.json()
    print(f'Nodes: {len(data.get("spec", {}).get("nodes", []))}')
    print(f'Diagram length: {len(data.get("diagram", ""))}')
    print('✓ Architecture endpoint working!')
else:
    print(f'Response headers: {dict(resp.headers)}')
    print(f'Response content-type: {resp.headers.get("content-type")}')
    print(f'Response body: {resp.text}')

