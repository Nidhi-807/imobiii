import requests
import time

# Give backend time to start
time.sleep(2)

# Test health first
print("=" * 70)
print("LLMaaS INTEGRATION TEST")
print("=" * 70)

try:
    resp = requests.get('http://127.0.0.1:8000/health', timeout=5)
    print(f'✓ Backend health: {resp.status_code}')
except Exception as e:
    print(f'✗ Backend not ready: {e}')
    exit(1)

# Test architecture generation with LLMaaS
print('\nTesting /architecture/generate with LLMaaS credentials...')
try:
    resp = requests.post(
        'http://127.0.0.1:8000/architecture/generate',
        json={'brief': 'Secure payment gateway with encryption', 'fmt': 'mermaid'},
        timeout=30
    )
    
    if resp.status_code == 200:
        data = resp.json()
        print(f'✓ Status: {resp.status_code}')
        print(f'✓ Response format: valid JSON')
        nodes_count = len(data.get("spec", {}).get("nodes", []))
        controls_count = len(data.get("spec", {}).get("controls", []))
        diagram_len = len(data.get("diagram", ""))
        print(f'✓ Nodes: {nodes_count}')
        print(f'✓ Controls: {controls_count}')
        print(f'✓ Diagram length: {diagram_len} chars')
        print(f'\n✓ LLMaaS INTEGRATION IS WORKING!')
        
        # Check if using LLM-generated content vs default template
        # LLM generates more nodes typically
        if nodes_count > 5:
            print(f'  → Using LLM-generated architecture (expanded from default)')
        else:
            print(f'  → Using deterministic default template')
    else:
        print(f'✗ Status: {resp.status_code}')
        print(f'  Response: {resp.text[:300]}')
except requests.exceptions.Timeout:
    print('⚠ Request timed out (LLMaaS endpoint may be slow or unreachable)')
    print('  Checking if deterministic fallback was used...')
    try:
        resp = requests.post(
            'http://127.0.0.1:8000/architecture/generate',
            json={'brief': 'Test', 'fmt': 'mermaid'},
            timeout=5
        )
        if resp.status_code == 200:
            print('  ✓ Fallback to deterministic template working')
    except:
        pass
except Exception as e:
    print(f'✗ Error: {type(e).__name__}: {e}')

print("\n" + "=" * 70)
