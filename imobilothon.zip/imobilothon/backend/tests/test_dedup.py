from app.agents.dedup_agent import run_dedup
from app.agents.schema import GuardrailDraft


def _draft(statement, domain="Information Security", severity="Mandatory", clause_id="CL-1", doc_id="DOC-1"):
    return GuardrailDraft(
        statement=statement,
        domain=domain,
        severity=severity,
        source_clause_id=clause_id,
        source_document_id=doc_id,
    )


def test_true_duplicates_merge_and_preserve_all_sources(session):
    drafts = [
        _draft(
            "Multi-factor authentication (MFA) is mandatory for all privileged and administrative account access.",
            clause_id="CL-A",
        ),
        _draft(
            "Remote and internet-facing access to corporate systems requires multi-factor authentication.",
            clause_id="CL-B",
        ),
    ]
    guardrails = run_dedup(session, drafts)

    assert len(guardrails) == 1
    merged = guardrails[0]
    assert merged.merged_from is not None
    source_clause_ids = {s.clause_id for s in merged.sources}
    assert source_clause_ids == {"CL-A", "CL-B"}, "dedup must preserve ALL source references, not drop one"


def test_unrelated_clauses_are_not_merged(session):
    drafts = [
        _draft("All data must be classified as Public, Internal, Confidential or Restricted.", clause_id="CL-A"),
        _draft("Critical severity vulnerabilities must be remediated within 14 days of identification.", clause_id="CL-B"),
    ]
    guardrails = run_dedup(session, drafts)
    assert len(guardrails) == 2, "unrelated clauses must not be merged into one guardrail"


def test_lexically_similar_but_different_values_are_not_merged(session):
    """Two clauses that read almost identically but state different numeric
    values (e.g. a 15-minute vs a 5-minute session timeout) are a conflict,
    not a duplicate -- merging them would destroy the signal the Conflict
    Agent needs. Regression test for a real bug caught via the shuffled-
    dataset rehearsal."""
    a = _draft(
        "Interactive sessions must be terminated after 15 minutes of inactivity.",
        clause_id="CL-A",
    )
    a.normalized_metric_group = "duration_days"
    a.normalized_value = 15 / 1440
    b = _draft(
        "Contractor sessions must be terminated after 5 minutes of inactivity.",
        clause_id="CL-B",
    )
    b.normalized_metric_group = "duration_days"
    b.normalized_value = 5 / 1440

    guardrails = run_dedup(session, [a, b])
    assert len(guardrails) == 2, "same wording but different stated values must not be silently merged"


def test_dedup_is_domain_scoped(session):
    drafts = [
        _draft("Logs must be retained for 12 months.", domain="Information Security", clause_id="CL-A"),
        _draft("Logs must be retained for 12 months.", domain="Privacy", clause_id="CL-B"),
    ]
    guardrails = run_dedup(session, drafts)
    assert len(guardrails) == 2, "identical wording in different domains should not silently merge across domains"
