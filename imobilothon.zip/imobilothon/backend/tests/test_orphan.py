from app.agents.orphan_agent import run_orphan_check
from app.db.models import Clause, Document, Guardrail, GuardrailSource


def test_broken_reference_is_flagged_and_valid_ones_are_not(session):
    session.add(Document(id="DOC-1", title="Real Doc", domain="Information Security"))
    session.add(Clause(id="CL-1", document_id="DOC-1", clause_text="Real clause text."))
    session.commit()

    good = Guardrail(id="GR-good", domain="Information Security", statement="A real requirement.", severity="Mandatory")
    bad = Guardrail(id="GR-bad", domain="Information Security", statement="An orphaned requirement.", severity="Mandatory")
    session.add_all([good, bad])
    session.flush()
    session.add(GuardrailSource(guardrail_id="GR-good", clause_id="CL-1", document_id="DOC-1"))
    session.add(GuardrailSource(guardrail_id="GR-bad", clause_id="CL-9999", document_id="DOC-9999"))
    session.commit()

    flagged = run_orphan_check(session)

    assert flagged == ["GR-bad"]
    session.refresh(good)
    session.refresh(bad)
    assert good.broken_reference is False
    assert bad.broken_reference is True
