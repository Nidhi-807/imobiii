"""
Builds tests/fixtures/shuffled_dataset.xlsx from the sample workbook:
renumbers every Document/Clause/Design ID, shuffles row order, and adds one
new duplicate clause and one new numeric conflict that were never in the
original sample -- proof the pipeline detects by meaning, not by memorized
IDs, since none of the sample IDs survive in this file and none of the new
scenarios existed when the code was written.

Run manually: python tests/fixtures/make_shuffled_dataset.py
"""
import random
import sys
from pathlib import Path

import openpyxl

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from app.config import DEFAULT_DATASET_PATH  # noqa: E402

random.seed(42)


def _remap(prefix: str, old_id, mapping: dict) -> str:
    if old_id not in mapping:
        mapping[old_id] = f"{prefix}-{9000 + len(mapping)}"
    return mapping[old_id]


def _rewrite_sheet(ws, transform_row):
    """Reads every data row into plain Python values FIRST (fully detached from the
    live worksheet), shuffles and transforms that detached copy, then writes it back.
    Mutating openpyxl Cell objects in place while other not-yet-read cells still alias
    the same worksheet corrupts data -- this avoids that entirely by never touching the
    sheet until every value has already been read out."""
    data_rows = [[cell.value for cell in row] for row in ws.iter_rows(min_row=2)]
    random.shuffle(data_rows)
    data_rows = [transform_row(row) for row in data_rows]
    for i, row in enumerate(data_rows, start=2):
        for j, value in enumerate(row, start=1):
            ws.cell(row=i, column=j, value=value)
    return data_rows


def main():
    wb = openpyxl.load_workbook(DEFAULT_DATASET_PATH, data_only=True)

    doc_map: dict = {}
    clause_map: dict = {}
    design_map: dict = {}

    def transform_document(row):
        row = list(row)
        row[0] = _remap("XDOC", row[0], doc_map)
        return row

    def transform_clause(row):
        row = list(row)
        row[0] = _remap("XCL", row[0], clause_map)
        row[1] = doc_map.get(row[1], row[1])
        return row

    def transform_design(row):
        row = list(row)
        row[0] = _remap("XDSN", row[0], design_map)
        return row

    _rewrite_sheet(wb["Governance_Documents"], transform_document)
    _rewrite_sheet(wb["Clauses"], transform_clause)
    _rewrite_sheet(wb["Design_Descriptions"], transform_design)

    # New scenarios nobody wrote code against: a fresh duplicate + a fresh conflict,
    # attached to one of the remapped documents so foreign keys stay valid.
    any_doc_id = next(iter(doc_map.values()))
    ws = wb["Clauses"]
    new_rows = [
        ("XCL-9500", any_doc_id, "9.1", "Session timeout",
         "Interactive sessions must be terminated after 15 minutes of inactivity."),
        ("XCL-9501", any_doc_id, "9.2", "Idle session handling",
         "User sessions left idle must be automatically logged out after 15 minutes without activity."),
        ("XCL-9502", any_doc_id, "9.3", "Contractor session timeout",
         "Contractor remote sessions must be automatically logged out after 5 minutes of inactivity for high-risk systems."),
    ]
    start = ws.max_row + 1
    for offset, values in enumerate(new_rows):
        for col, value in enumerate(values, start=1):
            ws.cell(row=start + offset, column=col, value=value)

    out_path = Path(__file__).resolve().parent / "shuffled_dataset.xlsx"
    wb.save(out_path)
    print(f"Wrote {out_path}")
    print(f"Remapped {len(doc_map)} documents, {len(clause_map)} clauses, {len(design_map)} designs.")
    print("Added XCL-9500/XCL-9501 (new duplicate: ~15-min session timeout, worded differently)")
    print("Added XCL-9502 (new conflict: 5-min timeout for the same underlying dimension)")


if __name__ == "__main__":
    main()
