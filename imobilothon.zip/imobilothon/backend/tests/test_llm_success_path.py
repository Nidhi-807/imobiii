"""
The team's LLM key is currently rate-limited (see llm/client.py's retry
logic), so every live call in this environment fails over to the
deterministic heuristic path -- which is correct behavior, but it means we
can't prove the *LLM-success* path is wired correctly just by running the
app today. These tests mock llm_client.complete() to return a valid
response and assert the pipeline actually uses it end-to-end (mode="llm",
not silently re-falling to heuristic) -- so that swapping in a working key
later is a config change, not a debugging session.
"""
from app.agents import auditor_agent, evaluation_agent
from app.agents.chat_composer import compose_evaluate_reply
from app.agents.extraction_agent import extract_guardrails_batch
from app.db.models import Clause, DesignDescription, Document, Guardrail


def _design(session, id="DSN-TEST", description="A test design."):
    d = DesignDescription(id=id, title="Test design", domain="Information Security", description=description)
    session.add(d)
    session.commit()
    return d


def _guardrail(session, id="GR-TEST", statement="Data must be encrypted at rest.", severity="Mandatory"):
    g = Guardrail(id=id, domain="Information Security", statement=statement, severity=severity)
    session.add(g)
    session.commit()
    return g


def test_evaluate_batch_uses_llm_result_when_call_succeeds(session, monkeypatch):
    design = _design(session)
    guardrail = _guardrail(session)

    def fake_complete(system, user, schema, model=None):
        return {"results": [{
            "guardrail_id": guardrail.id,
            "verdict": "Compliant",
            "evidence_quote": "A test design.",
            "plain_language": "The LLM confirmed this requirement is met.",
            "technical_detail": "LLM reasoning, not a keyword match.",
        }]}

    monkeypatch.setattr(evaluation_agent.llm_client, "is_configured", lambda: True)
    monkeypatch.setattr(evaluation_agent.llm_client, "complete", fake_complete)

    results = evaluation_agent.evaluate_batch(design, [guardrail])

    assert results[guardrail.id]["mode"] == "llm"
    assert results[guardrail.id]["verdict"] == "Compliant"
    assert results[guardrail.id]["plain_language"] == "The LLM confirmed this requirement is met."


def test_evaluate_batch_falls_back_to_heuristic_when_llm_still_fails(session, monkeypatch):
    """Companion to the success test above: the heuristic fallback must still
    fire when the call fails, so a bad key degrades gracefully rather than
    breaking the whole evaluate request."""
    design = _design(session, description="Nothing relevant here.")
    guardrail = _guardrail(session)

    def failing_complete(*args, **kwargs):
        raise evaluation_agent.llm_client.LLMCallFailed("simulated 429")

    monkeypatch.setattr(evaluation_agent.llm_client, "is_configured", lambda: True)
    monkeypatch.setattr(evaluation_agent.llm_client, "complete", failing_complete)

    results = evaluation_agent.evaluate_batch(design, [guardrail])

    assert results[guardrail.id]["mode"] == "heuristic"


def test_auditor_batch_uses_llm_result_when_call_succeeds(session, monkeypatch):
    design = _design(session, description="Data is encrypted at rest using AES-256.")
    guardrail = _guardrail(session)
    verdict = {
        "verdict": "Compliant",
        "evidence_quote": "Data is encrypted at rest using AES-256.",
        "mode": "llm",
    }

    def fake_complete(system, user, schema, model=None):
        return {"results": [{"guardrail_id": guardrail.id, "approved": True, "audit_note": "LLM confirmed evidence supports the verdict."}]}

    monkeypatch.setattr(auditor_agent.llm_client, "is_configured", lambda: True)
    monkeypatch.setattr(auditor_agent.llm_client, "complete", fake_complete)

    results = auditor_agent.audit_batch(design, [(guardrail, verdict)])

    assert results[guardrail.id]["approved"] is True
    assert "LLM confirmed" in results[guardrail.id]["audit_note"]


def test_extraction_batch_uses_llm_result_when_call_succeeds(session, monkeypatch):
    doc = Document(id="DOC-TEST", title="Test Doc", domain="Information Security", document_type="Policy", status="Active")
    session.add(doc)
    clause = Clause(id="CL-TEST", document_id=doc.id, clause_heading="Encryption", clause_text="All data must be encrypted at rest.")
    session.add(clause)
    session.commit()

    def fake_complete(system, user, schema, model=None):
        return {"results": [{
            "clause_id": clause.id,
            "statement": "Data must be encrypted at rest (LLM-extracted).",
            "severity": "Mandatory",
            "category": "Encryption",
        }]}

    monkeypatch.setattr("app.agents.extraction_agent.llm_client.is_configured", lambda: True)
    monkeypatch.setattr("app.agents.extraction_agent.llm_client.complete", fake_complete)

    drafts = extract_guardrails_batch([clause])

    assert len(drafts) == 1
    assert drafts[0].statement == "Data must be encrypted at rest (LLM-extracted)."
    assert drafts[0].source_clause_id == clause.id


def test_compose_evaluate_reply_uses_llm_answer_when_call_succeeds(monkeypatch):
    design = DesignDescription(id="DSN-TEST", title="Test design", domain="Information Security", description="x")
    findings = [{"verdict": "Compliant", "severity": "Mandatory", "plain_language": "Encryption is in place."}]

    def fake_complete(system, user, schema, model=None):
        return {"answer": "This design meets all checked requirements."}

    monkeypatch.setattr("app.agents.chat_composer.llm_client.is_configured", lambda: True)
    monkeypatch.setattr("app.agents.chat_composer.llm_client.complete", fake_complete)

    reply = compose_evaluate_reply(design, findings, analysis_mode_summary={"mode": "llm", "llm_count": 1, "heuristic_count": 0})

    assert reply == "This design meets all checked requirements."
