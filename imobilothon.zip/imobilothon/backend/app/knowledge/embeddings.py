"""
Local, offline "meaning" comparison for short compliance clauses.

Two signals are exposed:
- TextSimilarityIndex (TF-IDF cosine): good for retrieval against *longer*
  text (a design description paragraph vs many guardrails) where sentence
  length dilution isn't a big problem.
- content_word_overlap (stemmed-content-word Jaccard): much better for
  comparing two *short, single-sentence* clauses against each other, which
  is what dedup/conflict candidate-generation actually needs -- raw cosine
  over two terse sentences is dominated by scaffolding words ("must be...
  within...") and doesn't reliably separate true duplicates from merely
  topically-adjacent clauses. Neither signal is tied to any dataset-specific
  vocabulary; both are purely lexical/statistical.

Chosen over a transformer embedding model because a torch/transformers
version conflict made sentence-transformers unusable in this environment,
and the guide explicitly accepts classical-NLP / LLM-free approaches on
merit. When an LLM gateway *is* configured, agents should treat this
module's output as a cheap candidate filter and let the LLM make the final
call (see dedup_agent.py / conflict_agent.py) -- lexical overlap alone is a
recall tool, not a verdict.
"""
from __future__ import annotations

import re

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

_DOMAIN_STOPWORDS = {
    "must", "shall", "should", "may", "will", "required", "require", "requirement",
    "requirements", "ensure", "ensures", "within", "using", "use", "used", "prior",
    "before", "after", "where", "when", "unless", "applies", "applicable", "least",
    "minimum", "maximum", "least", "more", "than", "and", "or", "for", "of", "to",
    "a", "an", "the", "be", "is", "are", "with", "all", "any", "not", "no", "as",
    "at", "on", "in", "into", "per", "including", "such", "that", "this", "these",
    "those", "have", "has", "had",
}


def _tokenize(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _light_stem(word: str) -> str:
    """Cheap suffix stripping -- not a real stemmer, just enough to fold plurals
    and common verb endings so 'accounts'/'account', 'rotated'/'rotate' match."""
    for suffix in ("ies", "ing", "ed", "es", "s"):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[: -len(suffix)]
    return word


def _content_tokens(text: str) -> list[str]:
    words = _tokenize(text).split()
    return [_light_stem(w) for w in words if w not in _DOMAIN_STOPWORDS and len(w) > 1]


def content_word_overlap(a: str, b: str) -> float:
    """Jaccard similarity over stemmed content-word unigrams+bigrams. Robust to
    sentence-length differences that dilute cosine similarity on short clauses."""
    tokens_a, tokens_b = _content_tokens(a), _content_tokens(b)
    if not tokens_a or not tokens_b:
        return 0.0
    bigrams_a = {f"{x}_{y}" for x, y in zip(tokens_a, tokens_a[1:])}
    bigrams_b = {f"{x}_{y}" for x, y in zip(tokens_b, tokens_b[1:])}
    set_a = set(tokens_a) | bigrams_a
    set_b = set(tokens_b) | bigrams_b
    union = set_a | set_b
    if not union:
        return 0.0
    return len(set_a & set_b) / len(union)


class TextSimilarityIndex:
    """Fit once over a corpus of texts, then compare any texts against it or each other."""

    def __init__(self, texts: list[str]):
        self.texts = [_tokenize(t) for t in texts]
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            min_df=1,
            sublinear_tf=True,
        )
        self.matrix = self.vectorizer.fit_transform(self.texts) if self.texts else None

    def pairwise_similarity(self) -> np.ndarray:
        if self.matrix is None or self.matrix.shape[0] == 0:
            return np.zeros((0, 0))
        return cosine_similarity(self.matrix)

    def similarity_to_corpus(self, text: str) -> np.ndarray:
        if self.matrix is None or self.matrix.shape[0] == 0:
            return np.zeros((0,))
        vec = self.vectorizer.transform([_tokenize(text)])
        return cosine_similarity(vec, self.matrix)[0]


def pairwise_content_overlap_matrix(texts: list[str]) -> np.ndarray:
    n = len(texts)
    mat = np.zeros((n, n))
    tokens = [_content_tokens(t) for t in texts]
    sets = []
    for toks in tokens:
        bigrams = {f"{x}_{y}" for x, y in zip(toks, toks[1:])}
        sets.append(set(toks) | bigrams)
    for i in range(n):
        for j in range(i + 1, n):
            union = sets[i] | sets[j]
            score = len(sets[i] & sets[j]) / len(union) if union else 0.0
            mat[i, j] = mat[j, i] = score
    return mat


def pairwise_text_similarity(a: str, b: str) -> float:
    return content_word_overlap(a, b)
