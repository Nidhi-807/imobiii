"""
Generic numeric-requirement extraction, used by both the Extraction Agent
(to annotate a guardrail draft) and the Conflict Agent (to compare two
guardrails' concrete values within the same semantic topic cluster).

Deliberately not keyed to any specific policy vocabulary ("password",
"retention", ...) -- it just finds a number+unit and normalizes the unit so
two differently-worded clauses about the same underlying dimension become
numerically comparable. Topic similarity (via embeddings.py) is what decides
*whether* two guardrails are about the same dimension; this module only
extracts *what number* each one states.
"""
from __future__ import annotations

import re

_UNIT_GROUPS = {
    "duration_days": {
        "minute": 1 / 1440, "minutes": 1 / 1440,
        "hour": 1 / 24, "hours": 1 / 24,
        "day": 1, "days": 1,
        "week": 7, "weeks": 7,
        "month": 30, "months": 30,
        "year": 365, "years": 365,
    },
    "length_chars": {
        "character": 1, "characters": 1, "char": 1, "chars": 1,
    },
    "percent": {
        "%": 1, "percent": 1,
    },
}

_STOPWORDS = {
    "the", "a", "an", "of", "to", "for", "and", "or", "must", "should", "shall",
    "be", "is", "are", "at", "in", "on", "with", "least", "than", "more", "no",
    "not", "less", "up", "after", "before", "within",
}

_NUM_UNIT_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*-?\s*(minutes?|days?|weeks?|months?|years?|hours?|characters?|chars?|percent|%)",
    re.IGNORECASE,
)

# Generic verb-family taxonomy for *what kind* of duration a number describes.
# Not tied to any dataset vocabulary -- just common English verbs a governance
# clause about that dimension would plausibly use. This lets the Conflict Agent
# recognize "12 months retention" and "90 days purge" as the same underlying
# policy dimension (data lifecycle) even though they share almost no other
# words, without hardcoding to any specific clause/topic.
_SEMANTIC_SUBGROUPS = {
    "lifecycle": {"retain", "retained", "retention", "store", "stored", "keep", "kept",
                  "purge", "purged", "delete", "deleted", "anonymise", "anonymised",
                  "anonymize", "anonymized", "destroy", "destroyed", "dispose", "disposed",
                  "archive", "archived"},
    "sla_turnaround": {"remediate", "remediated", "respond", "responded", "report",
                        "reported", "resolve", "resolved", "revoke", "revoked",
                        "notify", "notified", "patch", "patched"},
    "recurrence": {"rotate", "rotated", "recertify", "recertified", "review", "reviewed",
                   "renew", "renewed", "refresh", "refreshed", "reassess", "reassessed"},
}


def _semantic_subgroup(text: str, near_pos: int | None = None) -> str | None:
    """When a clause uses verbs from more than one family (e.g. 'rotated ...
    and stored ...'), prefer whichever matched verb sits closest to the
    number, rather than whichever subgroup happens to be checked first --
    that's what the number actually quantifies."""
    text_lower = text.lower()
    best_subgroup, best_distance = None, None
    for subgroup, verbs in _SEMANTIC_SUBGROUPS.items():
        for verb in verbs:
            for m in re.finditer(rf"\b{re.escape(verb)}\b", text_lower):
                distance = abs(m.start() - near_pos) if near_pos is not None else m.start()
                if best_distance is None or distance < best_distance:
                    best_distance, best_subgroup = distance, subgroup
    return best_subgroup


def extract_numeric_requirement(text: str) -> dict | None:
    """Returns the first {metric_group, value, unit, label} found, or None."""
    match = _NUM_UNIT_RE.search(text)
    if not match:
        return None

    raw_value = float(match.group(1))
    raw_unit = match.group(2).lower()

    metric_group = None
    normalized_value = raw_value
    for group, units in _UNIT_GROUPS.items():
        for unit_key, factor in units.items():
            if raw_unit.rstrip("s") == unit_key.rstrip("s") or raw_unit == unit_key:
                metric_group = group
                normalized_value = raw_value * factor
                break
        if metric_group:
            break
    if metric_group is None:
        metric_group = "generic"

    # human-readable label: a handful of significant preceding words
    prefix = text[: match.start()]
    words = re.findall(r"[A-Za-z]+", prefix.lower())
    words = [w for w in words if w not in _STOPWORDS]
    label = " ".join(words[-5:]) if words else "requirement"

    return {
        "metric_group": metric_group,
        "value": normalized_value,
        "raw_value": raw_value,
        "unit": raw_unit,
        "label": label,
        "semantic_subgroup": _semantic_subgroup(text, near_pos=match.start()),
    }
