"""
Precedent Agent: the "learning" half of the reasoning approach. Every human
decision made in the Conflict Desk (Approve A / Approve B / Keep Open) is a
durable DB record (see conflicts/decision_store.py) -- this agent is what
actually looks back at that history and uses it.

This is deliberately *retrieval* over past decisions, not model fine-tuning:
the system doesn't need weights to update to "learn" here, it needs to
notice that a reviewer already resolved a structurally similar conflict and
say so. That's real learning-from-feedback in the sense that matters for
this platform -- each Conflict Desk decision measurably changes what the
Conflict Agent says the next time a similar conflict appears -- without
requiring an LLM fine-tune loop that would be out of scope for a hackathon
timeline.

Still non-binding: a precedent is surfaced as a factor in the rationale, and
`run_conflict_detection` never applies it automatically -- the whole point
of the Conflict Desk is that a human decides every time.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.db.models import ConflictTicket

_DECISION_LABEL = {
    "approved_a": "Approved A",
    "approved_b": "Approved B",
    "kept_open": "Kept Open",
}


def find_precedent(session: Session, metric: str | None) -> ConflictTicket | None:
    """Most recent *decided* ticket for the same normalized metric, if any."""
    if not metric:
        return None
    return (
        session.query(ConflictTicket)
        .filter(ConflictTicket.metric == metric, ConflictTicket.status != "open")
        .order_by(ConflictTicket.decided_at.desc())
        .first()
    )


def precedent_note(ticket: ConflictTicket) -> str:
    decided_label = _DECISION_LABEL.get(ticket.status, ticket.status)
    decided_date = ticket.decided_at.date().isoformat() if ticket.decided_at else "an earlier date"
    return (
        f"Learned from precedent: a structurally similar conflict ('{ticket.metric}', ticket {ticket.id}) "
        f"was already resolved by a human reviewer as '{decided_label}' on {decided_date}. Offered as context "
        f"for this new ticket, not applied automatically -- a reviewer still decides this one independently."
    )


def learning_summary(session: Session) -> dict:
    """Read-only visibility into how much learned precedent exists, surfaced
    in the reasoning-mode status (see routes_debug.llm_status)."""
    decided = session.query(ConflictTicket).filter(ConflictTicket.status != "open").all()
    metrics_covered = sorted({t.metric for t in decided if t.metric})
    return {
        "precedent_decisions": len(decided),
        "metrics_covered": metrics_covered,
    }
