"""
Dedup Agent: clusters GuardrailDrafts within the same domain by text
similarity and merges each cluster into one canonical Guardrail row --
unioning every source clause/document ID so nothing is silently dropped.
Clustering is purely by meaning (TF-IDF cosine over the statement text), so
it survives a modified dataset with different IDs and different wording of
the same rule.
"""
from __future__ import annotations

import uuid

import numpy as np
from sqlalchemy.orm import Session

from app.agents.schema import GuardrailDraft
from app.config import DEDUP_SIMILARITY_THRESHOLD
from app.db.models import Guardrail, GuardrailSource
from app.knowledge.embeddings import pairwise_content_overlap_matrix

_SEVERITY_RANK = {"Low": 0, "Medium": 1, "High": 2, "Mandatory": 3}


def _cluster(drafts: list[GuardrailDraft], threshold: float) -> list[list[int]]:
    """Greedy union-find clustering over the pairwise similarity matrix."""
    n = len(drafts)
    if n == 0:
        return []
    sim = pairwise_content_overlap_matrix([d.statement for d in drafts])

    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    def _conflicting_values(a: GuardrailDraft, b: GuardrailDraft) -> bool:
        """Two lexically-similar drafts that state *different* numeric values for the
        same dimension are a conflict, not a duplicate -- merging them would silently
        destroy the very signal the Conflict Agent needs to see. Leave them unmerged
        so conflict_agent.py gets a chance to open a ticket instead."""
        if not a.normalized_metric_group or not b.normalized_metric_group:
            return False
        if a.normalized_metric_group != b.normalized_metric_group:
            return False
        if a.normalized_value is None or b.normalized_value is None:
            return False
        return a.normalized_value != b.normalized_value

    for i in range(n):
        for j in range(i + 1, n):
            if sim[i, j] >= threshold and not _conflicting_values(drafts[i], drafts[j]):
                union(i, j)

    clusters: dict[int, list[int]] = {}
    for i in range(n):
        clusters.setdefault(find(i), []).append(i)
    return list(clusters.values())


def _merge_cluster(drafts: list[GuardrailDraft], indices: list[int]) -> Guardrail:
    members = [drafts[i] for i in indices]
    # canonical statement: the most detailed (longest) among the most severe members
    max_sev = max(_SEVERITY_RANK.get(m.severity, 0) for m in members)
    top = [m for m in members if _SEVERITY_RANK.get(m.severity, 0) == max_sev]
    canonical = max(top, key=lambda m: len(m.statement))

    numeric_member = next((m for m in members if m.normalized_metric_group), canonical)

    guardrail = Guardrail(
        id=f"GR-{uuid.uuid4().hex[:8]}",
        domain=canonical.domain,
        category=canonical.category,
        statement=canonical.statement,
        severity=canonical.severity,
        instruction_type=canonical.instruction_type,
        applicability=canonical.applicability,
        not_applicable=canonical.not_applicable,
        do_instructions=canonical.do_instructions,
        dont_instructions=canonical.dont_instructions,
        trigger_conditions=canonical.trigger_conditions,
        plain_language_guidance=canonical.plain_language_guidance,
        normalized_metric=numeric_member.normalized_metric_group,
        normalized_value=numeric_member.normalized_value,
        normalized_raw_value=numeric_member.normalized_raw_value,
        normalized_unit=numeric_member.normalized_unit,
        normalized_operator=None,
        normalized_subgroup=numeric_member.normalized_subgroup,
        merged_from=",".join(sorted({m.source_clause_id for m in members})) if len(members) > 1 else None,
    )

    return guardrail


def run_dedup(session: Session, drafts: list[GuardrailDraft]) -> list[Guardrail]:
    by_domain: dict[str, list[GuardrailDraft]] = {}
    for d in drafts:
        by_domain.setdefault(d.domain, []).append(d)

    created: list[Guardrail] = []
    for domain, domain_drafts in by_domain.items():
        clusters = _cluster(domain_drafts, DEDUP_SIMILARITY_THRESHOLD)
        for indices in clusters:
            guardrail = _merge_cluster(domain_drafts, indices)
            session.add(guardrail)
            session.flush()  # get guardrail.id available for FK rows
            for i in indices:
                m = domain_drafts[i]
                session.add(
                    GuardrailSource(
                        guardrail_id=guardrail.id,
                        clause_id=m.source_clause_id,
                        document_id=m.source_document_id,
                    )
                )
            created.append(guardrail)

    session.commit()
    return created
