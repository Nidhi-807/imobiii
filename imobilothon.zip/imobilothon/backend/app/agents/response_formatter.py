"""
Unified response formatter for all chat responses.
Ensures consistent, well-formatted, detailed responses across all endpoints.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.db.models import Guardrail


@dataclass
class FormattedSection:
    """A structured section of a response."""
    title: str
    content: str | list[str]
    is_list: bool = False


def format_not_architecture_response(overview: str) -> dict[str, Any]:
    """Response for an upload/description that doesn't depict a system or
    architecture at all -- skips running a full guardrail evaluation against
    unrelated content (e.g. a random photo) rather than reporting a
    confusing wall of "Gap" findings for something with nothing architectural
    in it."""
    message = (
        overview
        or "This doesn't look like an architecture or system description -- there's nothing "
        "architectural in it to evaluate against guardrails."
    )
    return {
        "intent": "diagram",
        "reply": message,
        "sections": [{"title": "Not an Architecture Diagram", "content": message}],
        "summary": message,
    }


def build_summary_from_report(report: dict) -> tuple[dict, str, int, list[dict]]:
    """Convert a build_report() result into the {overall, counts} shape the
    diagram/adhoc-design formatter expects, plus a plain-language reasoning
    string, the number of guardrails actually shortlisted as relevant (which
    can be > 0 even when every finding below was suppressed), and the
    combined findings + suppressed list for display.

    Using len(findings) alone as "how many guardrails were checked" was a
    bug: `findings` only contains ones that survived the Auditor Agent and
    citation gate, so a relevant-but-unconfirmable design looked identical
    to "no guardrails matched at all"."""
    findings = report.get("findings", [])
    suppressed = report.get("unverified_suppressed", [])
    counts = {
        "compliant": len([f for f in findings if f["verdict"] == "Compliant"]),
        "non_compliant": len([f for f in findings if f["verdict"] == "Non-compliant"]),
        "gap": len([f for f in findings if f["verdict"] == "Gap"]),
        "unevaluated": len(suppressed),
    }
    overall_verdict = report.get("overall_verdict") or {}
    status_map = {
        "Non-compliant": "non_compliant",
        "Incomplete": "gap",
        "Compliant": "compliant",
        "Gap": "gap",
    }
    overall = status_map.get(overall_verdict.get("status"), "gap")
    reasoning = overall_verdict.get("summary", "")
    if not findings and suppressed:
        reasoning = (
            f"{len(suppressed)} guardrail{'s' if len(suppressed) != 1 else ''} looked relevant to this design, "
            "but none could be confirmed with a verifiable citation -- the Auditor Agent or citation gate "
            "rejected the evidence. Adding specific technical detail (exact encryption standards, named "
            "access-control mechanisms, monitoring tools, etc.) usually resolves this."
        )

    shortlisted_count = report.get("negative_space", {}).get("shortlisted_count", len(findings))
    combined_results = findings + suppressed
    return {"overall": overall, "counts": counts}, reasoning, shortlisted_count, combined_results


def format_search_response(
    message: str,
    ranked_guardrails: list[tuple[Guardrail, float]],
    reply: str,
) -> dict[str, Any]:
    """Format a guardrail search response with detailed structure."""
    sections = []
    
    # Overview section
    if ranked_guardrails:
        match_count = len(ranked_guardrails)
        sections.append({
            "title": "Search Results",
            "content": f"Found {match_count} guardrail{'s' if match_count != 1 else ''} relevant to: \"{message}\""
        })
    
    # Main answer
    sections.append({
        "title": "Analysis",
        "content": reply
    })
    
    return {
        "intent": "search",
        "reply": reply,  # Backward compatibility for frontend
        "sections": sections,
        "summary": reply,
    }


def format_evaluate_response(
    design_title: str,
    design_id: str,
    findings: list[dict],
    overall_verdict: str,
    analysis_mode: str = "heuristic",
) -> dict[str, Any]:
    """Format a design evaluation response with detailed structure."""
    non_compliant = [f for f in findings if f["verdict"] == "Non-compliant"]
    gaps = [f for f in findings if f["verdict"] == "Gap"]
    compliant = [f for f in findings if f["verdict"] == "Compliant"]
    
    sections = []
    
    # Design overview
    sections.append({
        "title": "Design Under Review",
        "content": f"**{design_title}** (ID: {design_id})"
    })
    
    # Overall compliance status
    sections.append({
        "title": "Compliance Status",
        "content": f"**Overall: {overall_verdict.upper()}**\n"
                   f"Evaluated against {len(findings)} guardrails | Analysis Mode: {analysis_mode}"
    })
    
    # Findings summary
    sections.append({
        "title": "Findings Summary",
        "content": _build_findings_summary(non_compliant, gaps, compliant)
    })
    
    # Recommendations
    if non_compliant or gaps:
        recommendations = _build_recommendations(non_compliant, gaps)
        if recommendations:
            sections.append({
                "title": "Recommendations",
                "content": recommendations
            })
    
    summary_text = _build_evaluate_summary(design_title, non_compliant, gaps, compliant)
    
    return {
        "intent": "evaluate",
        "reply": summary_text,  # Backward compatibility for frontend
        "sections": sections,
        "summary": summary_text,
    }


def format_conflict_response(
    tickets: list[Any],
    analysis: str,
    query: str,
) -> dict[str, Any]:
    """Format a conflict analysis response with detailed structure."""
    sections = []
    
    # Overview
    ticket_count = len(tickets)
    sections.append({
        "title": "Open Conflicts",
        "content": f"Found {ticket_count} open conflict{'s' if ticket_count != 1 else ''} in the Conflict Desk"
    })
    
    # LLM Analysis
    sections.append({
        "title": "Strategic Analysis",
        "content": analysis
    })
    
    # Conflict details
    if tickets:
        conflict_details = []
        for i, ticket in enumerate(tickets[:10], 1):  # Show up to 10
            conflict_details.append(
                f"{i}. **Ticket {ticket.id}**: {ticket.metric}\n"
                f"   Guardrail A: {ticket.guardrail_id_a} vs Guardrail B: {ticket.guardrail_id_b}\n"
                f"   Status: {ticket.status.upper()}"
            )
        sections.append({
            "title": "Conflict Details",
            "content": "\n\n".join(conflict_details),
            "is_list": True
        })
    
    return {
        "intent": "conflicts",
        "reply": analysis,  # Backward compatibility for frontend
        "sections": sections,
        "summary": analysis,
    }


def format_diagram_evaluation_response(
    facts_description: dict,
    summary: dict,
    results: list[dict],
    checked_guardrails_count: int,
    verdict_reasoning: str | None = None,
) -> dict[str, Any]:
    """Format an architecture diagram evaluation response."""
    non_compliant = [r for r in results if r["verdict"] == "Non-compliant"]
    gaps = [r for r in results if r["verdict"] == "Gap"]
    compliant = [r for r in results if r["verdict"] == "Compliant"]
    
    sections = []
    
    # Architecture overview
    overview = facts_description.get("overview", "Architecture diagram analyzed.")
    sections.append({
        "title": "Architecture Overview",
        "content": overview
    })
    
    # Extracted components
    components = facts_description.get("components", [])
    if components:
        component_list = [f["name"] for f in components[:8]]
        sections.append({
            "title": "Detected Components",
            "content": ", ".join(component_list) + (f" and {len(components) - 8} more" if len(components) > 8 else "")
        })
    
    overall = summary.get("overall", "gap").upper()
    counts = summary.get("counts", {})
    no_guardrails_checked = checked_guardrails_count == 0

    # Compliance status
    if no_guardrails_checked:
        compliance_text = (
            "**No relevant guardrails found**\n"
            "None of the guardrails in the knowledge base matched this architecture closely enough to evaluate. "
            "This isn't a pass -- it means there's nothing on record to check it against yet."
        )
    else:
        compliance_text = (
            f"**Overall: {overall}**\n"
            f"Checked against {checked_guardrails_count} relevant guardrail{'s' if checked_guardrails_count != 1 else ''}"
        )
    sections.append({
        "title": "Compliance Status",
        "content": compliance_text
    })

    # Why this verdict
    if verdict_reasoning and not no_guardrails_checked:
        sections.append({
            "title": "Why This Verdict",
            "content": verdict_reasoning
        })
    
    # Findings summary
    if no_guardrails_checked:
        summary_text = (
            f"{overview} No relevant guardrails were found in the knowledge base for this architecture, "
            "so no compliance verdict could be produced."
        )
    else:
        summary_text = (
            f"{overview} Overall verdict: {overall.title()}. "
            f"{counts.get('compliant', 0)} compliant, "
            f"{counts.get('non_compliant', 0)} non-compliant, "
            f"{counts.get('gap', 0)} gap "
            + (f"and {counts.get('unevaluated', 0)} unevaluated " if counts.get('unevaluated', 0) else "")
            + f"out of {checked_guardrails_count} guardrails checked."
        )
        sections.append({
            "title": "Evaluation Summary",
            "content": (
                f"**Compliant**: {counts.get('compliant', 0)} | "
                f"**Non-compliant**: {counts.get('non_compliant', 0)} | "
                f"**Gap**: {counts.get('gap', 0)} | "
                f"**Unevaluated**: {counts.get('unevaluated', 0)}"
            )
        })
    
    # Exposure signals
    exposure_signals = facts_description.get("exposure_signals", [])
    if exposure_signals:
        high_severity = [s for s in exposure_signals if s.get("severity") in ["Critical", "High"]]
        if high_severity:
            signals = []
            for sig in high_severity[:5]:
                signals.append(
                    f"**{sig['signal'].replace('_', ' ').title()}** at {sig['location']}\n"
                    f"   Evidence: {sig['evidence'][:60]}"
                )
            sections.append({
                "title": "Security Signals",
                "content": "\n\n".join(signals),
                "is_list": True
            })
    
    return {
        "intent": "diagram",
        "reply": summary_text,  # Backward compatibility for frontend
        "sections": sections,
        "summary": summary_text,
    }


# Helper functions

def _build_findings_summary(non_compliant: list, gaps: list, compliant: list) -> str:
    """Build a summary of findings counts and severity."""
    parts = []
    
    if non_compliant:
        critical_count = len([f for f in non_compliant if f.get("severity") in ["Mandatory", "High", "Critical"]])
        parts.append(f"**{len(non_compliant)} Non-compliant** guardrails" + 
                    (f" ({critical_count} critical severity)" if critical_count > 0 else ""))
    
    if gaps:
        parts.append(f"**{len(gaps)} Gap** findings (inconclusive)")
    
    if compliant:
        parts.append(f"**{len(compliant)} Compliant** guardrails")
    
    return " | ".join(parts) if parts else "No findings yet."


def _build_evaluate_summary(design_title: str, non_compliant: list, gaps: list, compliant: list) -> str:
    """Build a summary sentence for evaluate responses."""
    parts = []
    total = len(non_compliant) + len(gaps) + len(compliant)
    
    parts.append(f"Evaluated '{design_title}' against {total} guardrails.")
    
    if non_compliant:
        parts.append(f"{len(non_compliant)} Non-compliant findings identified.")
    if gaps:
        parts.append(f"{len(gaps)} gaps found (could not determine compliance).")
    if compliant:
        parts.append(f"{len(compliant)} guardrails satisfied.")
    
    return " ".join(parts)


def _build_recommendations(non_compliant: list, gaps: list) -> str:
    """Build recommendations based on findings."""
    recommendations = []
    
    if non_compliant:
        critical = [f for f in non_compliant if f.get("severity") in ["Mandatory", "High"]]
        if critical:
            recommendations.append(
                f"1. **Priority**: Address {len(critical)} critical non-compliant finding"
                f"{'s' if len(critical) != 1 else ''} immediately"
            )
    
    if gaps:
        recommendations.append(
            f"2. **Clarification**: Gather additional evidence for {len(gaps)} gap finding"
            f"{'s' if len(gaps) != 1 else ''}"
        )
    
    if non_compliant or gaps:
        recommendations.append(
            "3. **Review**: Check the citations below for exact source clauses and guidance"
        )
    
    return " | ".join(recommendations)
