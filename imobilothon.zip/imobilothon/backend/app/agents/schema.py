from __future__ import annotations

from pydantic import BaseModel, Field


class GuardrailDraft(BaseModel):
    """What the Extraction Agent produces from a single clause, before dedup."""

    statement: str = Field(..., description="The requirement, in plain language.")
    domain: str
    category: str | None = None
    severity: str = Field(..., description="Low | Medium | High | Mandatory")
    instruction_type: str | None = None  # Mandatory / Recommended / Principle / Standard
    applicability: str | None = None
    not_applicable: str | None = None
    do_instructions: str | None = None
    dont_instructions: str | None = None
    trigger_conditions: str | None = None
    plain_language_guidance: str | None = None
    source_clause_id: str
    source_document_id: str

    # normalized numeric requirement, if the clause states one (for conflict detection)
    normalized_metric_group: str | None = None  # "duration_days" | "length_chars" | "count" | "percent"
    normalized_value: float | None = None  # canonical/comparable (e.g. months converted to days)
    normalized_raw_value: float | None = None  # original stated number, for display (e.g. 12, not 360)
    normalized_unit: str | None = None  # original stated unit, for display (e.g. "months")
    normalized_label: str | None = None  # human-readable, e.g. "log retention period"
    normalized_subgroup: str | None = None  # "lifecycle" | "sla_turnaround" | "recurrence"
