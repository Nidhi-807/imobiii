"""
Read-only clause lookup, used by the frontend's citation preview panel --
clicking a citation in chat (or anywhere else) should show the actual
source text, not just an ID.
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.db.models import Clause, Document
from app.db.session import get_session

router = APIRouter(prefix="/clauses", tags=["clauses"])


@router.get("/{clause_id}")
def get_clause(clause_id: str):
    session = get_session()
    try:
        clause = session.get(Clause, clause_id)
        if clause is None:
            raise HTTPException(404, f"No clause '{clause_id}'")
        document = session.get(Document, clause.document_id)
        return {
            "id": clause.id,
            "clause_ref": clause.clause_ref,
            "clause_heading": clause.clause_heading,
            "clause_text": clause.clause_text,
            "document_id": clause.document_id,
            "document_title": document.title if document else None,
            "document_domain": document.domain if document else None,
            "document_version": document.version if document else None,
            "document_effective_date": document.effective_date if document else None,
        }
    finally:
        session.close()
