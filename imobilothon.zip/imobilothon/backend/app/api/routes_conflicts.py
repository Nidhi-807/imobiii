from __future__ import annotations

import json

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from app import auth
from app.conflicts.decision_store import decide, list_tickets
from app.db.models import AdminUser, ConflictTicket, Guardrail
from app.db.session import get_session

router = APIRouter(prefix="/conflicts", tags=["conflicts"])


def _serialize(ticket, session) -> dict:
    ga = session.get(Guardrail, ticket.guardrail_id_a)
    gb = session.get(Guardrail, ticket.guardrail_id_b)
    return {
        "id": ticket.id,
        "metric": ticket.metric,
        "rationale": ticket.rationale,
        "recommended_resolution": ticket.recommended_resolution,
        "impact_analysis": json.loads(ticket.impact_analysis) if ticket.impact_analysis else None,
        "status": ticket.status,
        "decided_by": ticket.decided_by,
        "decided_at": ticket.decided_at.isoformat() if ticket.decided_at else None,
        "assigned_to": ticket.assigned_to,
        "guardrail_a": {"id": ga.id, "statement": ga.statement, "value": ga.normalized_value} if ga else None,
        "guardrail_b": {"id": gb.id, "statement": gb.statement, "value": gb.normalized_value} if gb else None,
    }


class DecisionRequest(BaseModel):
    decision: str  # approved_a | approved_b | kept_open


class AssignRequest(BaseModel):
    assigned_to: str  # AdminUser.username


@router.get("")
def get_tickets(status: str | None = None):
    session = get_session()
    try:
        return [_serialize(t, session) for t in list_tickets(session, status)]
    finally:
        session.close()


@router.post("/{ticket_id}/decision")
def post_decision(ticket_id: str, req: DecisionRequest, authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        admin = auth.require_admin(session, authorization)
        ticket = decide(session, ticket_id, req.decision, admin.username)
        return _serialize(ticket, session)
    except LookupError as e:
        raise HTTPException(404, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        session.close()


@router.post("/{ticket_id}/assign")
def assign_ticket(ticket_id: str, req: AssignRequest, authorization: str | None = Header(default=None)):
    """Route a ticket to a specific reviewer -- the in-app stand-in for
    'mail sent to the designated person': no external email dependency,
    just a durable assignment the assignee sees as a notification next time
    they open the Admin Console."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
        ticket = session.get(ConflictTicket, ticket_id)
        if ticket is None:
            raise HTTPException(404, f"No conflict ticket '{ticket_id}'")
        if not session.query(AdminUser).filter(AdminUser.username == req.assigned_to).first():
            raise HTTPException(400, f"No registered admin with username '{req.assigned_to}'.")
        ticket.assigned_to = req.assigned_to
        session.commit()
        return _serialize(ticket, session)
    finally:
        session.close()


@router.get("/notifications/mine")
def my_assigned_tickets(authorization: str | None = Header(default=None)):
    """Open tickets assigned to the signed-in admin -- polled by the Admin
    Console to show a notification badge."""
    session = get_session()
    try:
        admin = auth.require_admin(session, authorization)
        tickets = (
            session.query(ConflictTicket)
            .filter(ConflictTicket.assigned_to == admin.username, ConflictTicket.status == "open")
            .all()
        )
        return [_serialize(t, session) for t in tickets]
    finally:
        session.close()
