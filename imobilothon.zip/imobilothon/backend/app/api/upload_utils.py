"""Shared "read an uploaded .txt/.md/.pdf file and extract its text" helper
for every admin form that offers a file-upload shortcut instead of typing
content by hand (designs, documents, guardrails). One place for the
validation + size limit + error mapping so each router's endpoint stays a
one-liner."""
from __future__ import annotations

from fastapi import HTTPException, UploadFile

from app.ingestion.text_extractor import TextExtractionFailed, extract_text

MAX_UPLOAD_BYTES = 2 * 1024 * 1024  # 2MB


async def read_and_extract(file: UploadFile) -> str:
    is_pdf = (file.content_type == "application/pdf") or file.filename.lower().endswith(".pdf")
    is_text = (file.content_type or "").startswith("text/") or file.filename.lower().endswith((".txt", ".md"))
    if not is_pdf and not is_text:
        raise HTTPException(400, "Only plain text files (.txt, .md) or PDFs (.pdf) are supported.")
    contents = await file.read()
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(400, "File too large (max 2MB).")
    try:
        return extract_text(contents, file.filename, file.content_type)
    except TextExtractionFailed as e:
        raise HTTPException(400, str(e))
