"""
Routes for architecture evaluation and generation.
"""
from __future__ import annotations

import base64
import logging
from typing import Any

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

from app.db.session import get_session
from app.generate.architecture_generator import (
    generate_reference_architecture,
    render_dot,
    render_mermaid,
)
from app.agents.response_formatter import format_diagram_evaluation_response
from app.vision.architecture_agent import evaluate_architecture, extract_facts

logger = logging.getLogger("guardrailiq")

router = APIRouter(prefix="/architecture", tags=["architecture"])


class ArchitectureEvaluateRequest(BaseModel):
    """Request for diagram evaluation with optional OCR text."""

    ocr_text: str | None = None


class ArchitectureGenerateRequest(BaseModel):
    """Request for reference architecture generation."""

    brief: str
    fmt: str = "mermaid"  # "mermaid" or "dot"


@router.post("/evaluate")
async def evaluate_diagram(file: UploadFile = File(...), ocr_text: str | None = None):
    """
    Evaluate an architecture diagram for compliance against guardrails.

    Returns:
        {
          "facts": ArchitectureFacts dict,
          "summary": {overall, counts},
          "results": [evaluation results with citations]
        }
    """
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "File must be an image (PNG, JPEG, WebP)")

    # Read and encode image
    image_bytes = await file.read()
    image_base64 = base64.b64encode(image_bytes).decode("utf-8")

    # Extract facts from diagram
    facts = extract_facts(image_base64, ocr_text)

    # Evaluate against guardrails
    session = get_session()
    try:
        evaluation = evaluate_architecture(facts, session)
        
        # Format with enhanced response structure
        formatted = format_diagram_evaluation_response(
            evaluation.get("facts_description", {}),
            evaluation.get("summary", {}),
            evaluation.get("results", []),
            evaluation.get("checked_guardrails_count", 0),
        )
        
        return {
            **formatted,
            "facts_extracted": facts.to_dict(),
            "checked_guardrails_count": evaluation.get("checked_guardrails_count", 0),
        }
    finally:
        session.close()


@router.post("/generate")
def generate_architecture(req: ArchitectureGenerateRequest):
    """
    Generate a compliant-by-construction reference architecture from a brief.

    Returns:
        {
          "spec": architecture specification,
          "format": "mermaid" or "dot",
          "diagram": rendered diagram (Mermaid or DOT syntax)
        }
    """
    session = get_session()
    try:
        logger.info(f"Generate request received: brief={req.brief[:50]}, fmt={req.fmt}")
        
        # Generate from brief with guardrails retrieved from DB
        spec = generate_reference_architecture(req.brief, session=session)
        logger.info(f"Spec generated with {len(spec.get('nodes', []))} nodes")

        # Render to requested format
        if req.fmt == "dot":
            diagram = render_dot(spec)
        else:  # Default to mermaid
            diagram = render_mermaid(spec)

        logger.info(f"Diagram rendered: {len(diagram)} chars")
        result = {"spec": spec, "format": req.fmt, "diagram": diagram}
        logger.info("Returning result")
        
        return result
    except Exception as e:
        logger.exception(f"Error generating architecture: {e}")
        raise HTTPException(500, f"Architecture generation failed: {str(e)}")
    finally:
        session.close()
