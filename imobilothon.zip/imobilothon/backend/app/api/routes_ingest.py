"""
POST /ingest/upload is "Judge Mode": run the identical pipeline against any
workbook matching the sheet shapes, not just the pre-rehearsed fixture.
POST /ingest/default re-runs it against the shipped sample dataset (used at
startup and by the demo's "reset" button).
"""
from __future__ import annotations

from fastapi import APIRouter, File, HTTPException, UploadFile
import io

from app.config import DEFAULT_DATASET_PATH
from app.db.session import get_session
from app.pipeline import run_full_pipeline

router = APIRouter(prefix="/ingest", tags=["ingest"])


@router.post("/upload")
async def ingest_upload(file: UploadFile = File(...)):
    if not file.filename.endswith(".xlsx"):
        raise HTTPException(400, "Please upload an .xlsx workbook matching the GuardrailIQ sheet shapes.")
    contents = await file.read()
    session = get_session()
    try:
        result = run_full_pipeline(session, io.BytesIO(contents))
        result["source"] = f"judge_mode_upload:{file.filename}"
        return result
    finally:
        session.close()


@router.post("/default")
def ingest_default():
    session = get_session()
    try:
        result = run_full_pipeline(session, DEFAULT_DATASET_PATH)
        result["source"] = "default_dataset"
        return result
    finally:
        session.close()
