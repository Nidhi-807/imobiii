from __future__ import annotations

import uuid

from fastapi import APIRouter, File, Header, HTTPException, UploadFile
from pydantic import BaseModel

from app import auth
from app.agents.conflict_agent import run_conflict_detection
from app.api.upload_utils import read_and_extract
from app.db.session import get_session
from app.db.models import Clause, Guardrail, GuardrailSource
from app.knowledge.numeric import extract_numeric_requirement

router = APIRouter(prefix="/guardrails", tags=["guardrails"])


def _serialize(g: Guardrail) -> dict:
    return {
        "id": g.id,
        "domain": g.domain,
        "category": g.category,
        "statement": g.statement,
        "severity": g.severity,
        "instruction_type": g.instruction_type,
        "applicability": g.applicability,
        "not_applicable": g.not_applicable,
        "do_instructions": g.do_instructions,
        "dont_instructions": g.dont_instructions,
        "trigger_conditions": g.trigger_conditions,
        "plain_language_guidance": g.plain_language_guidance,
        "broken_reference": g.broken_reference,
        "merged_from": g.merged_from.split(",") if g.merged_from else [],
        "is_duplicate_merge": bool(g.merged_from),
        "sources": [{"clause_id": s.clause_id, "document_id": s.document_id} for s in g.sources],
    }


@router.get("")
def list_guardrails(domain: str | None = None, severity: str | None = None, q: str | None = None):
    session = get_session()
    try:
        query = session.query(Guardrail)
        if domain:
            query = query.filter(Guardrail.domain == domain)
        if severity:
            query = query.filter(Guardrail.severity == severity)
        guardrails = query.all()
        if q:
            ql = q.lower()
            guardrails = [g for g in guardrails if ql in (g.statement or "").lower()]
        return [_serialize(g) for g in guardrails]
    finally:
        session.close()


@router.get("/domains")
def list_domains():
    session = get_session()
    try:
        rows = session.query(Guardrail.domain).distinct().all()
        return sorted({r[0] for r in rows})
    finally:
        session.close()


@router.get("/{guardrail_id}")
def get_guardrail(guardrail_id: str):
    session = get_session()
    try:
        g = session.get(Guardrail, guardrail_id)
        if g is None:
            raise HTTPException(404, f"No guardrail '{guardrail_id}'")
        return _serialize(g)
    finally:
        session.close()


class CreateGuardrailRequest(BaseModel):
    domain: str
    statement: str
    severity: str
    category: str | None = None
    applicability: str | None = None
    do_instructions: str | None = None
    dont_instructions: str | None = None
    source_clause_ids: list[str]


@router.post("/admin/extract-file", tags=["admin"])
async def extract_guardrail_file(file: UploadFile = File(...), authorization: str | None = Header(default=None)):
    """Reads a .txt/.md/.pdf file and returns its text to prefill the Add
    Guardrail form's requirement-statement field -- extraction only, the
    guardrail itself is still created via the separate, explicit POST
    below (which still requires real source clause IDs either way)."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
    finally:
        session.close()

    text = await read_and_extract(file)
    return {"text": text}


@router.post("/admin", tags=["admin"])
def create_guardrail(req: CreateGuardrailRequest, authorization: str | None = Header(default=None)):
    """Manually add a guardrail -- still held to the same rules everything
    else in the model is:
    - it must cite at least one real clause (unlike orphan detection, which
      *flags* a broken reference after the fact, this rejects the request
      outright so a hand-added guardrail can never enter the model already
      broken);
    - it's checked against every existing guardrail for a cross-document
      conflict just like the bulk ingestion pipeline does, so a hand-added
      guardrail that disagrees with an existing one opens a Conflict Desk
      ticket instead of silently sitting alongside it unnoticed."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
        if not req.source_clause_ids:
            raise HTTPException(400, "A guardrail must cite at least one source clause.")

        clauses = {c.id: c for c in session.query(Clause).filter(Clause.id.in_(req.source_clause_ids)).all()}
        missing = [cid for cid in req.source_clause_ids if cid not in clauses]
        if missing:
            raise HTTPException(400, f"Unknown clause ID(s): {', '.join(missing)}. Fix or remove them and try again.")

        numeric = extract_numeric_requirement(req.statement)

        guardrail = Guardrail(
            id=f"GR-{uuid.uuid4().hex[:8]}",
            domain=req.domain,
            category=req.category,
            statement=req.statement,
            severity=req.severity,
            applicability=req.applicability,
            do_instructions=req.do_instructions,
            dont_instructions=req.dont_instructions,
            normalized_metric=numeric["metric_group"] if numeric else None,
            normalized_value=numeric["value"] if numeric else None,
            normalized_raw_value=numeric["raw_value"] if numeric else None,
            normalized_unit=numeric["unit"] if numeric else None,
            normalized_subgroup=numeric["semantic_subgroup"] if numeric else None,
        )
        session.add(guardrail)
        session.flush()
        for cid in req.source_clause_ids:
            session.add(GuardrailSource(guardrail_id=guardrail.id, clause_id=cid, document_id=clauses[cid].document_id))
        session.commit()

        new_tickets = run_conflict_detection(session)

        result = _serialize(guardrail)
        result["new_conflict_tickets"] = [t.id for t in new_tickets]
        return result
    finally:
        session.close()
