"""
End-to-end: workbook -> Clauses/Documents/Designs -> Extraction Agent (per
clause) -> Dedup Agent (merge) -> Orphan Agent (validate) -> Conflict Agent
(open tickets). This is what both the startup ingestion and the "Judge
Mode" live-upload endpoint call -- same code path either way, which is the
point: nothing here is special-cased to the sample file.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.agents.conflict_agent import run_conflict_detection
from app.agents.dedup_agent import run_dedup
from app.agents.extraction_agent import extract_guardrails_batch
from app.agents.orphan_agent import run_orphan_check
from app.db.models import (
    Clause,
    ConflictTicket,
    DesignDescription,
    Document,
    Guardrail,
    GuardrailRelationship,
    GuardrailSource,
)
from app.ingestion.excel_loader import load_workbook


def reset_for_new_ingest(session: Session) -> None:
    """Every ingest reflects *only* the workbook being loaded -- a full
    replace, not an accumulate. This matters most for Judge Mode: a modified
    copy almost always uses a different ID namespace than whatever was
    loaded before (that's the whole point of the anti-hardcoding
    rehearsal), so upserting by primary key would silently leave the old
    workbook's rows in place alongside the new ones instead of replacing
    them. Guardrails are already rebuilt fresh each run; this clears the raw
    tables the same way.

    Decided tickets are deliberately kept -- they're the Conflict Agent's
    learned precedent (see agents/precedent_agent.py) and are looked up by
    `metric`, not by guardrail ID, so they stay meaningful even after the
    guardrails they originally referenced are gone. Only *open* tickets
    (which reference guardrail IDs about to be deleted) are cleared; they'd
    be stale until this run regenerates them anyway."""
    session.query(GuardrailSource).delete()
    session.query(GuardrailRelationship).delete()
    session.query(ConflictTicket).filter(ConflictTicket.status == "open").delete()
    session.query(Guardrail).delete()
    session.query(Clause).delete()
    session.query(DesignDescription).delete()
    session.query(Document).delete()
    session.commit()


def run_full_pipeline(session: Session, file_or_path) -> dict:
    reset_for_new_ingest(session)

    load_counts = load_workbook(session, file_or_path)

    clauses = session.query(Clause).all()
    drafts = extract_guardrails_batch(clauses)

    guardrails = run_dedup(session, drafts)
    broken = run_orphan_check(session)
    tickets = run_conflict_detection(session)

    return {
        "ingested": load_counts,
        "clauses_extracted": len(drafts),
        "guardrails_created": len(guardrails),
        "duplicates_merged": sum(1 for g in guardrails if g.merged_from),
        "broken_references": broken,
        "conflict_tickets_opened": len(tickets),
    }
