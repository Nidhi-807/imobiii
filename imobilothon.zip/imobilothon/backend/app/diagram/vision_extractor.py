"""
Turns an uploaded architecture-diagram image into a design-description-
shaped text blob, then hands off to the exact same evaluation pipeline text
designs go through -- no separate evaluation logic for images. There's no
sample diagram in the provided dataset, so this only ever runs against
whatever a user actually attaches in chat.

Requires a vision-capable model; there is no meaningful offline fallback for
"what does this picture show" the way there is for text heuristics, so this
raises plainly rather than fabricating a description when no LLM is
configured.
"""
from __future__ import annotations

from app.llm import client as llm_client


class VisionNotAvailable(RuntimeError):
    pass


_SYSTEM_PROMPT = (
    "You are the Diagram Agent in CompliX. You are given an architecture diagram image. "
    "Describe the system it depicts in plain language, as if writing a design description "
    "for a governance review: components, data flows, where data is hosted, what "
    "authentication/encryption/access-control measures are shown or implied, and any "
    "third parties or public-facing elements. Be concrete and only describe what is "
    "actually visible or clearly labeled in the diagram -- do not invent components. "
    "Output only the JSON object described by the schema."
)

_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "description": {"type": "string"},
    },
    "required": ["description"],
}


def extract_design_description(image_base64: str, mime_type: str, filename: str) -> dict:
    if not llm_client.is_configured():
        raise VisionNotAvailable(
            "Diagram analysis needs a connected vision-capable LLM, and none is configured right now."
        )
    result = llm_client.complete_vision(
        _SYSTEM_PROMPT,
        f"Diagram file: {filename}. Describe it for a compliance review.",
        image_base64,
        mime_type,
        _JSON_SCHEMA,
    )
    return {
        "title": result.get("title") or filename,
        "description": result.get("description", ""),
    }
