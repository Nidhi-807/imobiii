"""
Assembles one design's full evaluation report: retrieval (with negative
space) -> per-guardrail verdict -> Auditor Agent critique -> deterministic
citation gate -> a risk-sorted, fully-cited findings list. Every finding
that reaches "shown" status has survived both trust layers; anything either
layer rejected is still returned, but clearly separated and labeled
Unverified, never silently dropped.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.agents import auditor_agent, citation_gate, evaluation_agent
from app.db.models import DesignDescription
from app.evaluation.retriever import retrieve_candidates

_SEVERITY_RANK = {"Low": 0, "Medium": 1, "High": 2, "Mandatory": 3}
_VERDICT_RANK = {"Non-compliant": 3, "Gap": 2, "Unverified": 1, "Compliant": 0}


def build_report(session: Session, design_id: str) -> dict:
    design = session.get(DesignDescription, design_id)
    if design is None:
        raise LookupError(f"No design '{design_id}'")

    retrieval = retrieve_candidates(session, design)
    verdicts_by_id = evaluation_agent.evaluate_batch(design, [c.guardrail for c in retrieval.shortlist])
    audits_by_id = auditor_agent.audit_batch(
        design,
        [(c.guardrail, verdicts_by_id.get(c.guardrail.id) or evaluation_agent.evaluate(design, c.guardrail)) for c in retrieval.shortlist],
    )

    findings = []
    for considered in retrieval.shortlist:
        guardrail = considered.guardrail
        raw_verdict = verdicts_by_id.get(guardrail.id) or evaluation_agent.evaluate(design, guardrail)
        audit = audits_by_id.get(guardrail.id) or auditor_agent.audit(design, guardrail, raw_verdict)

        primary_clause_id = guardrail.sources[0].clause_id if guardrail.sources else None
        finding = {
            "guardrail_id": guardrail.id,
            "guardrail_statement": guardrail.statement,
            "domain": guardrail.domain,
            "severity": guardrail.severity,
            "clause_id": primary_clause_id,
            "all_clause_ids": [s.clause_id for s in guardrail.sources],
            "verdict": raw_verdict.get("verdict", "Gap"),
            "evidence_quote": raw_verdict.get("evidence_quote", ""),
            "plain_language": raw_verdict.get("plain_language", ""),
            "technical_detail": raw_verdict.get("technical_detail", ""),
            "retrieval_similarity": round(considered.similarity, 3),
            "retrieval_reason": considered.reason,
            "auditor_approved": audit["approved"],
            "audit_note": audit["audit_note"],
            "analysis_mode": raw_verdict.get("mode", "heuristic"),
        }

        if not audit["approved"]:
            finding["verdict"] = "Unverified"
            finding["status"] = "suppressed"
            finding["citation_gate_passed"] = None
            finding["citation_gate_reason"] = "Rejected by Auditor Agent before reaching the citation gate."
        else:
            citation_gate.gate_finding(session, finding)

        findings.append(finding)

    findings.sort(
        key=lambda f: (_VERDICT_RANK.get(f["verdict"], 0), _SEVERITY_RANK.get(f["severity"], 0)),
        reverse=True,
    )

    shown = [f for f in findings if f["status"] == "shown"]
    suppressed = [f for f in findings if f["status"] == "suppressed"]

    return {
        "design_id": design.id,
        "design_title": design.title,
        "domain": design.domain,
        "findings": shown,
        "unverified_suppressed": suppressed,
        "overall_verdict": _overall_verdict(shown),
        "analysis_mode_summary": _analysis_mode_summary(shown),
        "negative_space": {
            "considered_count": retrieval.considered_count,
            "shortlisted_count": len(retrieval.shortlist),
            "rejected": [
                {"guardrail_id": c.guardrail.id, "similarity": round(c.similarity, 3), "reason": c.reason}
                for c in retrieval.rejected
            ],
        },
    }


def _overall_verdict(findings: list[dict]) -> dict:
    """A single architecture-level compliance call, on top of the per-guardrail
    findings: Mandatory/High severity findings decide it, since those are the
    requirements a design cannot be excused from meeting."""
    decisive = [f for f in findings if f["severity"] in ("Mandatory", "High")]
    pool = decisive or findings

    violations = [f for f in pool if f["verdict"] == "Non-compliant"]
    gaps = [f for f in pool if f["verdict"] == "Gap"]

    if violations:
        status = "Non-compliant"
        summary = (
            f"Non-compliant -- {len(violations)} mandatory/high-severity guardrail(s) are violated"
            + (f", and {len(gaps)} more couldn't be confirmed" if gaps else "") + "."
        )
    elif gaps:
        status = "Incomplete"
        summary = f"No confirmed violations, but {len(gaps)} mandatory/high-severity guardrail(s) lack enough information to confirm compliance."
    elif pool:
        status = "Compliant"
        summary = "All mandatory/high-severity guardrails that were checked are satisfied."
    else:
        status = "Gap"
        summary = "No guardrails were relevant enough to this design to evaluate."

    return {"status": status, "summary": summary, "violation_count": len(violations), "gap_count": len(gaps)}


def _analysis_mode_summary(findings: list[dict]) -> dict:
    """Whether findings were actually produced by the LLM or by the
    deterministic keyword fallback -- surfaced honestly rather than a trace
    that claims 'LLM-backed reasoning' regardless of what really ran."""
    llm_count = sum(1 for f in findings if f.get("analysis_mode") == "llm")
    heuristic_count = len(findings) - llm_count
    if heuristic_count == 0:
        mode = "llm"
    elif llm_count == 0:
        mode = "heuristic"
    else:
        mode = "mixed"
    return {"mode": mode, "llm_count": llm_count, "heuristic_count": heuristic_count}
