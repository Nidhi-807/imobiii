"""
Prompts for architecture generation from policy guardrails.
"""

ARCH_GENERATION_PROMPT = """You are an architecture designer building a COMPLIANT-BY-CONSTRUCTION 
system architecture from a governance brief and policy guardrails.

Given:
1. A brief describing the system's purpose and constraints
2. A set of governance guardrails (security, privacy, compliance requirements)

Generate a complete architecture where EVERY mandated node, edge, and control cites the exact guardrail 
and clause it satisfies. When a guardrail permits baseline choices (e.g. "use TLS or equivalent"), list 
those as baseline_choices with rationale. When a concern has no guardrail to support it, put it in gaps 
(never invent a rule).

Return a JSON object:
{
  "title": "Architecture title",
  "description": "Summary of design rationale",
  "nodes": [
    {
      "id": "unique_node_id",
      "name": "Human-readable component name",
      "type": "service|database|gateway|storage|auth|queue|cache",
      "description": "What it does",
      "satisfies": [
        {"guardrail_id": "id", "clause_ref": "e.g. SOC2-1.2", "document": "policy doc name"}
      ]
    }
  ],
  "boundaries": [
    {
      "id": "boundary_id",
      "name": "Trust boundary name",
      "description": "What separates what",
      "inside": ["node_ids"],
      "outside": ["node_ids"]
    }
  ],
  "edges": [
    {
      "id": "edge_id",
      "from": "source_node_id",
      "to": "target_node_id",
      "protocol": "https|http|grpc|tcp|amqp",
      "encryption": "required|optional|none",
      "authentication": "required|optional|none",
      "description": "Purpose of this connection",
      "satisfies": [
        {"guardrail_id": "id", "clause_ref": "e.g. InfoSec-3.1", "document": "..."}
      ]
    }
  ],
  "controls": [
    {
      "id": "control_id",
      "name": "Control name (e.g., Secret Storage, Encryption at Rest)",
      "description": "How it works",
      "applied_to": ["node_ids or edge_ids this protects"],
      "satisfies": [
        {"guardrail_id": "id", "clause_ref": "ref", "document": "..."}
      ]
    }
  ],
  "baseline_choices": [
    {
      "concern": "What architectural decision this addresses",
      "options": ["Option A", "Option B"],
      "rationale": "Why these are equivalent and compliant",
      "guardrail_references": [
        {"guardrail_id": "id", "allows_choice": true}
      ]
    }
  ],
  "gaps": [
    {
      "concern": "What requirement or best practice is not covered",
      "why": "Why there's no guardrail for this",
      "recommendation": "Suggested control"
    }
  ]
}

DEFAULT SECURE DESIGN:
Unless overridden by guardrails, default to:
- Authenticated gateway at the external boundary (all external traffic through auth layer first)
- HTTPS/mTLS on every boundary-crossing edge
- Encryption-at-rest on all classified data stores
- Managed secret store (no inline secrets, no hardcoded credentials)
- No localhost, dev hostnames, or development flags in production
- Audit logging on sensitive operations
- MFA for administrative access

For each guardrail's normalized_value (e.g., retention period), use it directly in the architecture 
(e.g., "logs retained for X days").

Return ONLY valid JSON, no prose. If the brief is ambiguous, list assumptions in gaps.
"""
