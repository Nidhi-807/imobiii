"""
Architecture Generation Agent: Generate compliant-by-construction architectures
from policy guardrails with citation grounding and diagram rendering.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from sqlalchemy.orm import Session

from app.db.models import Clause, Guardrail
from app.evaluation.retriever import retrieve_candidates
from app.llm import client as llm_client
from app.generate.prompts import ARCH_GENERATION_PROMPT

logger = logging.getLogger("guardrailiq")

# Default secure architecture template used when LLM unavailable
_DEFAULT_SECURE_TEMPLATE = {
    "title": "Default Secure Architecture",
    "description": "Baseline secure design with authentication gateway, HTTPS/mTLS on all boundaries, encryption-at-rest, managed secrets, audit logging.",
    "nodes": [
        {
            "id": "auth_gateway",
            "name": "Authentication Gateway",
            "type": "gateway",
            "description": "Entry point for all external requests; enforces authentication/MFA",
            "satisfies": [],
        },
        {
            "id": "api_service",
            "name": "API Service",
            "type": "service",
            "description": "Core business logic",
            "satisfies": [],
        },
        {
            "id": "data_db",
            "name": "Data Store",
            "type": "database",
            "description": "Persistent data with encryption-at-rest",
            "satisfies": [],
        },
        {
            "id": "secret_store",
            "name": "Secret Management",
            "type": "storage",
            "description": "Centralized credential/key storage",
            "satisfies": [],
        },
        {
            "id": "audit_log",
            "name": "Audit Log",
            "type": "storage",
            "description": "Immutable audit trail",
            "satisfies": [],
        },
    ],
    "boundaries": [
        {
            "id": "boundary_external",
            "name": "External Boundary",
            "description": "Separates internet from internal systems",
            "inside": ["api_service", "data_db", "secret_store", "audit_log"],
            "outside": ["auth_gateway"],
        }
    ],
    "edges": [
        {
            "id": "edge_client_to_gateway",
            "from": "client",
            "to": "auth_gateway",
            "protocol": "https",
            "encryption": "required",
            "authentication": "required",
            "description": "Client to auth gateway",
            "satisfies": [],
        },
        {
            "id": "edge_gateway_to_api",
            "from": "auth_gateway",
            "to": "api_service",
            "protocol": "https",
            "encryption": "required",
            "authentication": "required",
            "description": "Authenticated gateway to API (mTLS)",
            "satisfies": [],
        },
        {
            "id": "edge_api_to_db",
            "from": "api_service",
            "to": "data_db",
            "protocol": "tcp",
            "encryption": "required",
            "authentication": "required",
            "description": "API to database (encrypted connection)",
            "satisfies": [],
        },
    ],
    "controls": [
        {
            "id": "ctrl_encryption_rest",
            "name": "Encryption at Rest",
            "description": "All data stores use AES-256 encryption",
            "applied_to": ["data_db", "secret_store", "audit_log"],
            "satisfies": [],
        },
        {
            "id": "ctrl_mfa",
            "name": "Multi-Factor Authentication",
            "description": "MFA required for privileged access",
            "applied_to": ["auth_gateway", "secret_store"],
            "satisfies": [],
        },
        {
            "id": "ctrl_audit",
            "name": "Audit Logging",
            "description": "All sensitive operations logged with user/timestamp/action",
            "applied_to": ["api_service", "secret_store", "data_db"],
            "satisfies": [],
        },
        {
            "id": "ctrl_secret_management",
            "name": "Secret Management",
            "description": "All credentials stored in centralized secret manager, rotated regularly",
            "applied_to": ["secret_store"],
            "satisfies": [],
        },
    ],
    "baseline_choices": [
        {
            "concern": "Database encryption algorithm",
            "options": ["AES-256", "AES-192"],
            "rationale": "Both meet NIST standards; AES-256 preferred for higher security",
            "guardrail_references": [],
        }
    ],
    "gaps": [],
}


def generate_reference_architecture(
    brief: str, guardrails: list[dict] | None = None, session: Session | None = None
) -> dict[str, Any]:
    """
    Generate a reference architecture from a brief and guardrails.
    Falls back to deterministic default-secure template if LLM unavailable.

    Args:
        brief: System description and requirements
        guardrails: List of guardrail dicts with id, statement, domain, etc.
                   If None, retrieves from database using brief as query.
        session: SQLAlchemy session for retrieval (required if guardrails is None)

    Returns:
        Spec dict with nodes, edges, controls, satisfies citations.
    """
    if guardrails is None and session is not None:
        # Retrieve guardrails from database using brief as query
        retrieval = retrieve_candidates(session, _FakeDesign(brief))
        guardrails = []
        for c in retrieval.shortlist:
            sources = []
            for s in c.guardrail.sources:
                clause = session.get(Clause, s.clause_id)
                doc_title = clause.document.title if clause and clause.document else s.document_id
                sources.append(
                    {
                        "document": doc_title,
                        "clause_ref": s.clause_id,
                        "clause_text": clause.clause_text if clause else "",
                    }
                )
            guardrails.append(
                {
                    "guardrail_id": c.guardrail.id,
                    "statement": c.guardrail.statement,
                    "domain": c.guardrail.domain,
                    "normalized_value": c.guardrail.normalized_value,
                    "sources": sources,
                }
            )
    elif guardrails is None:
        guardrails = []

    # Try LLM-based generation if configured
    if llm_client.is_configured() and guardrails:
        try:
            spec = _generate_architecture_llm(brief, guardrails)
            if session:
                spec = _validate_citations(spec, session, guardrails)
            return spec
        except llm_client.LLMNotConfigured:
            pass
        except Exception as e:
            logger.warning(f"Architecture generation LLM call failed: {e}, using default template")

    # Deterministic fallback: default secure template with guardrail citations
    spec = json.loads(json.dumps(_DEFAULT_SECURE_TEMPLATE))  # Deep copy
    if guardrails and session:
        spec = _cite_default_template(spec, guardrails, session)
    return spec


def _generate_architecture_llm(brief: str, guardrails: list[dict]) -> dict[str, Any]:
    """Call LLM to generate architecture from brief and guardrails."""
    guardrails_text = json.dumps(guardrails, indent=2)
    prompt = f"""Brief:
{brief}

Available Guardrails:
{guardrails_text}

{ARCH_GENERATION_PROMPT}"""

    result = llm_client.complete(
        system="You are an expert security architect designing a compliant-by-construction system.",
        user=prompt,
        json_schema={
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "description": {"type": "string"},
                "nodes": {"type": "array"},
                "boundaries": {"type": "array"},
                "edges": {"type": "array"},
                "controls": {"type": "array"},
                "baseline_choices": {"type": "array"},
                "gaps": {"type": "array"},
            },
        },
    )

    return result


def _cite_default_template(spec: dict, guardrails: list[dict], session: Session) -> dict[str, Any]:
    """
    Augment default template with guardrail citations from database.
    """
    guardrail_map = {g["guardrail_id"]: g for g in guardrails}
    guardrail_db_map = {}
    for gr_id in guardrail_map:
        gr = session.get(Guardrail, gr_id)
        if gr:
            guardrail_db_map[gr_id] = gr

    # Find encryption/auth/audit guardrails and cite them
    for gr_id, gr_dict in guardrail_map.items():
        gr_db = guardrail_db_map.get(gr_id)
        if not gr_db or not gr_db.sources:
            continue

        statement_lower = gr_dict.get("statement", "").lower()
        domain = gr_dict.get("domain", "")

        # Map guardrails to default controls by keyword
        if any(kw in statement_lower for kw in ["encrypt", "aes", "cryptograph"]):
            # Encryption guardrail -> encryption-at-rest control
            for ctrl in spec.get("controls", []):
                if "encrypt" in ctrl.get("name", "").lower():
                    if "satisfies" not in ctrl:
                        ctrl["satisfies"] = []
                    source = gr_db.sources[0]
                    clause = session.get(Clause, source.clause_id)
                    doc_title = clause.document.title if clause and clause.document else source.document_id
                    ctrl["satisfies"].append(
                        {
                            "guardrail_id": gr_id,
                            "clause_ref": source.clause_id,
                            "document": doc_title,
                        }
                    )
                    break

        if any(kw in statement_lower for kw in ["auth", "mfa", "multifactor"]):
            # Auth guardrail -> MFA control
            for ctrl in spec.get("controls", []):
                if "mfa" in ctrl.get("name", "").lower():
                    if "satisfies" not in ctrl:
                        ctrl["satisfies"] = []
                    source = gr_db.sources[0]
                    clause = session.get(Clause, source.clause_id)
                    doc_title = clause.document.title if clause and clause.document else source.document_id
                    ctrl["satisfies"].append(
                        {
                            "guardrail_id": gr_id,
                            "clause_ref": source.clause_id,
                            "document": doc_title,
                        }
                    )
                    break

        if any(kw in statement_lower for kw in ["audit", "log", "logging"]):
            # Audit guardrail -> audit control
            for ctrl in spec.get("controls", []):
                if "audit" in ctrl.get("name", "").lower():
                    if "satisfies" not in ctrl:
                        ctrl["satisfies"] = []
                    source = gr_db.sources[0]
                    clause = session.get(Clause, source.clause_id)
                    doc_title = clause.document.title if clause and clause.document else source.document_id
                    ctrl["satisfies"].append(
                        {
                            "guardrail_id": gr_id,
                            "clause_ref": source.clause_id,
                            "document": doc_title,
                        }
                    )
                    break

    return spec


def _validate_citations(spec: dict, session: Session, provided_guardrails: list[dict]) -> dict[str, Any]:
    """
    Validate that all citations in the spec exist in provided_guardrails.
    Demote unvalidated citations to baseline_choices.
    """
    provided_ids = {g["guardrail_id"] for g in provided_guardrails}

    for component_list in [spec.get("nodes", []), spec.get("edges", []), spec.get("controls", [])]:
        for component in component_list:
            satisfies = component.get("satisfies", [])
            valid_satisfies = []
            invalid_satisfies = []

            for citation in satisfies:
                if citation.get("guardrail_id") in provided_ids:
                    valid_satisfies.append(citation)
                else:
                    invalid_satisfies.append(citation)

            component["satisfies"] = valid_satisfies

            # Move invalid citations to baseline_choices (no guardrail backing)
            if invalid_satisfies:
                concern = f"{component.get('name', 'Unknown')}: {component.get('description', '')}"
                spec.setdefault("baseline_choices", []).append(
                    {
                        "concern": concern,
                        "options": ["See architectural description"],
                        "rationale": "No matching guardrail in provided set; requires separate review",
                        "guardrail_references": invalid_satisfies,
                    }
                )

    return spec


def render_mermaid(spec: dict) -> str:
    """
    Render architecture spec to Mermaid diagram syntax (for frontend rendering).
    """
    lines = ["graph TB"]

    # Add nodes
    node_map = {}
    for node in spec.get("nodes", []):
        node_id = node.get("id", "")
        name = node.get("name", "")
        node_type = node.get("type", "service")
        node_map[node_id] = name

        # Node styling by type
        shape = "[" if node_type == "gateway" else "("
        end_shape = "]" if node_type == "gateway" else ")"
        lines.append(f"    {node_id}{shape}{name}{end_shape}")

    # Add edges
    for edge in spec.get("edges", []):
        from_id = edge.get("from", "")
        to_id = edge.get("to", "")
        protocol = edge.get("protocol", "tcp").upper()
        encryption = "🔒" if edge.get("encryption") == "required" else ""
        label = f"{protocol} {encryption}".strip()

        if from_id in node_map and to_id in node_map:
            lines.append(f"    {from_id} -->|{label}| {to_id}")
        elif from_id not in node_map:
            lines.append(f"    {from_id}[{from_id}]")
            lines.append(f"    {from_id} -->|{label}| {to_id}")

    return "\n".join(lines)


def render_dot(spec: dict) -> str:
    """
    Render architecture spec to Graphviz DOT syntax (for PNG/SVG export).
    """
    lines = [
        "digraph architecture {",
        '  rankdir=TB;',
        '  node [shape=box, style=rounded];',
        '  edge [fontsize=10];',
        "",
    ]

    # Add nodes with labels
    for node in spec.get("nodes", []):
        node_id = node.get("id", "")
        name = node.get("name", "")
        node_type = node.get("type", "service")

        # Shape and color by type
        if node_type == "gateway":
            shape = "component"
            color = "#ffcccc"
        elif node_type == "database":
            shape = "cylinder"
            color = "#ccffcc"
        elif node_type == "storage":
            shape = "box"
            color = "#ffffcc"
        else:
            shape = "box"
            color = "#ccccff"

        satisfies_count = len(node.get("satisfies", []))
        label = f"{name}" + (f"\\n[{satisfies_count} cites]" if satisfies_count else "")
        lines.append(
            f'  {node_id} [label="{label}", shape={shape}, fillcolor="{color}", style="rounded,filled"];'
        )

    lines.append("")

    # Add edges with labels
    for edge in spec.get("edges", []):
        from_id = edge.get("from", "")
        to_id = edge.get("to", "")
        protocol = edge.get("protocol", "tcp").upper()
        encryption = "ENC" if edge.get("encryption") == "required" else ""
        label = f"{protocol}\\n{encryption}".strip()

        lines.append(f'  {from_id} -> {to_id} [label="{label}"];')

    lines.append("}")
    return "\n".join(lines)


class _FakeDesign:
    """Minimal design stand-in for retrieval.retrieve_candidates()."""

    def __init__(self, text: str):
        self.description = text
        self.domain = "Information Security"
